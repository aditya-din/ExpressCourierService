<?php #logout here.
session_start();
$_SESSION['adminName']="";
session_destroy();
header("Location: http://localhost/ExpressCourier/Admin/adminlogin.php");

?>