<?php
$conn = mysqli_connect('localhost','root','','expressCourier');
if(!$conn){
    echo "<script>alert('some error in connecting db')</script>";
}else{
    $query = "select * from booking";
    $result = mysqli_query($conn,$query);
    $count = 0;
    while($row = mysqli_fetch_array($result)){
        $count+=1;
    }
    echo "$count";
}


?>