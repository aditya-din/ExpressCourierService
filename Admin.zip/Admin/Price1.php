<?php
session_start();
if ($_SESSION['adminName']==""){
	echo "You must login first";
	header("Location: http://localhost/ExpressCourier/Admin/adminlogin.php");
}

?>
<!DOCTYPE HTML>
<html>
<head>
<title>ECS</title>
<meta http-equiv="Content-Type" content="text/html charset=utf-8" />
<meta name="keywords" content="Minimal Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, 
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<link href="css/bootstrap.min.css" rel='stylesheet' type='text/css' />
<!-- Custom Theme files -->
<link href="css/style.css" rel='stylesheet' type='text/css' />
<link href="css/font-awesome.css" rel="stylesheet"> 
<!--<script src="js/jquery.min.js"> </script>-->
<!-- Mainly scripts -->
<!--<script src="js/jquery.metisMenu.js"></script>
<script src="js/jquery.slimscroll.min.js"></script>-->
<!-- Custom and plugin javascript -->
<link href="css/custom.css" rel="stylesheet">
<!--<script src="js/custom.js"></script>-->
<!--script src="js/bootstrap.min.js"></script>-->
<script src="js/screenfull.js"></script>
<!-- price table -->
<link href="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js"></script>
<script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
		<script>
		$(function () {
			$('#supported').text('Supported/allowed: ' + !!screenfull.enabled);

			if (!screenfull.enabled) {
				return false;
			}

			

			$('#toggle').click(function () {
				screenfull.toggle($('#container')[0]);
			});
			

			
		});
		</script>

<!----->
<!--skycons-icons-->
<script src="js/skycons.js"></script>
<!--//skycons-icons-->
<style>
#drop{
 margin:13px;
}
#drop1{
 margin:12px;
 width:12px;
 height:auto;
}
.dropdown{
  width:140px;
 }
 #footer{
    width:1200px;
 }
</style>
<!-- price table-->
<style>
* {
  box-sizing: border-box;
}

#myInput {
  background-image: url('/css/searchicon.png');
  background-position: 10px 10px;
  background-repeat: no-repeat;
  width: 100%;
  font-size: 16px;
  padding: 12px 20px 12px 40px;
  border: 1px solid #ddd;
  margin-bottom: 12px;
}

#myTable {
  border-collapse: collapse;
  width: 100%;
  border: 1px solid #ddd;
  font-size: 18px;
}

#myTable th, #myTable td {
  text-align: left;
  padding: 12px;
}
#myTable tr {
  border-bottom: 1px solid #ddd;
}

#myTable tr.header, #myTable tr:hover {
  background-color: #f1f1f1;
}
* {
  box-sizing: border-box;
}

#myInput {
  background-image: url('css/searchicon.png');
  background-position: 10px 10px;
  background-repeat: no-repeat;
  width: 100%;
  font-size: 16px;
  padding: 12px 20px 12px 40px;
  border: 1px solid #ddd;
  margin-bottom: 12px;
}

#myTable {
  border-collapse: collapse;
  width: 100%;
  border: 1px solid #ddd;
  font-size: 18px;
}

#myTable th, #myTable td {
  text-align: left;
  padding: 12px;
}

#myTable tr {
  border-bottom: 1px solid #ddd;
}

#myTable tr.header, #myTable tr:hover {
  background-color: #f1f1f1;
}
</style>
<script>
function myFunction() {
  var input, filter, table, tr, td, i, txtValue;
  input = document.getElementById("myInput");
  filter = input.value.toUpperCase();
  table = document.getElementById("myTable");
  tr = table.getElementsByTagName("tr");
  for (i = 0; i < tr.length; i++) {
    td = tr[i].getElementsByTagName("td")[1];
    if (td) {
      txtValue = td.textContent || td.innerText;
      if (txtValue.toUpperCase().indexOf(filter) > -1) {
        tr[i].style.display = "";
      } else {
        tr[i].style.display = "none";
      }
    }       
  }
}
</script>
</head>
<body>
  <style>
    #side-menu {
      width:259px;
    }
  </style>  
<div id="wrapper">


        <nav class="navbar-default navbar-static-top" role="navigation">
             <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
               <h1> <a class="navbar-brand" href="index.php">ECS</a></h1>         
			   </div>
			 <div class=" border-bottom">
        	<div class="full-left">
        	  <section class="full-top">
				     <button id="toggle"><i class="fa fa-arrows-alt"></i></button>	
			        </section>
			       <!--<form class=" navbar-left-right">
              <input type="text"  value="Search..." onfocus="this.value = '';" onblur="if (this.value == '') {this.value = 'Search...';}">
              <input type="submit" value="" class="fa fa-search">
            </form>-->
            <div class="clearfix"> </div>
           </div>
     
       
            <!-- Brand and toggle get grouped for better mobile display -->
		 
		   <!-- Collect the nav links, forms, and other content for toggling -->
		    <div class="drop-men" >
		        <ul class=" nav_1">
		           <li class="dropdown" id="drop">
		              <a href="adminSignout.php"><span class=" name-caret">logout</span><img src=""></a>
		            </li>
		       </ul>
		     </div><!-- /.navbar-collapse -->
			<div class="clearfix">
       
     </div>
	  
		    <div class="navbar-default sidebar" role="navigation">
                <div class="sidebar-nav navbar-collapse">
                <ul class="nav" id="side-menu">
				            <li>
                        <a href="index.php" class=" hvr-bounce-to-right"><i class="fa fa-dashboard nav_icon "></i><span class="nav-label">Dashboards</span> </a>
                    </li>
                  
					          <li>
                        <a href="Price1.php" class=" hvr-bounce-to-right"><i class="fa fa-inbox nav_icon"></i> <span class="nav-label">Price Table</span> </a>
                    </li>
                    
                    <li>
                        <a href="admin.php" class=" hvr-bounce-to-right"><i class="fa fa-picture-o nav_icon"></i> <span class="nav-label">Add Employee</span> </a>
                    </li>
                  
                     <li>
                        <a href="profile.php" class=" hvr-bounce-to-right"><i class="fa fa-th nav_icon"></i> <span class="nav-label">Profile</span> </a>
                    </li>
                 </ul>
              </div>
			    </div>
        </nav>
        <div id="page-wrapper" class="gray-bg dashbard-1">
       <div class="content-main">
 
  		<!--banner-->	
		    <div class="banner">
		   <h2>
				<a href="index.php">Home</a>
				<i class="fa fa-angle-right"></i>
				<span>Dashboard</span>
				</h2>
		    </div>
			<div class="container-fluid">
			<input type="text" id="myInput" onkeyup="myFunction()" placeholder="Search for Range.." title="Type in a name">
       <div class="container search-table">
            <div class="search-list">
                <h3>Price List for Parcel & Document</h3>
                <table class="table" id="myTable" style="border:4px;">
                    <thead>
                        <tr>
                            <th style="width:170px;align:center">SI.No</th>
                            <th style="width:170px;align:center">Range</th>
                            <th style="width:170px;align:center">Price(local)</th>
	                        <th style="width:170px;align:center">upto 200kms</th>
                        </tr>
                    </thead>
                    <tbody>
                    <tr>
                          <td>1</td>
                          <td>Up to 50 Gms</td>
                          <td>Rs 18</td>
	                      <td>Rs 41</td>
                    </tr>
                    <tr>
                        <td>2</td>
                        <td>51 Grams to</td>
                        <td>Rs 30</td>
	                    <td>Rs 41</td>
                    </tr>
                    <tr>
                        <td>3</td>
                        <td>201 to 500 Grams</td>
                        <td>Rs 35</td>
	                    <td>Rs 59</td>
                    </tr>
                    <tr>
                         <td>4</td>
                         <td>501 to 1000 Grams</td>
                         <td>Rs 47</td>
	                     <td>Rs 77</td>
                    </tr>
                    <tr>
                          <td>5</td>
                          <td>1001 to 1500 Grams</td>
                          <td>Rs 59</td>
	                      <td>Rs 94</td>
                    </tr>
                    <tr>
                         <td>6</td>
                         <td>1501 to 2000 Grams</td>
                         <td>Rs 71</td>
	                     <td>Rs 112</td>
                    </tr>
                    <tr>
                         <td>7</td>
                         <td>2001 to 2500 Grams</td>
                         <td>Rs 83</td>
	                     <td>Rs 130</td>
                    </tr>
                    <tr>
                         <td>8</td>
                         <td>2501 to 3000 Grams</td>
                         <td>Rs 94</td>
	                     <td>Rs 148</td>
                    </tr>
					            <tr>
                         <td>9</td>
                         <td>3001 to 3500 Grams</td>
                         <td>Rs 106</td>
	                     <td>Rs 165</td>
                    </tr>
                    </tbody>
                </table>
			</div>
    </div>
  </div>	
      <div class="copy" id="footer">
            <p> &copy; 2020 ECS. All Rights Reserved | Design by <a href="http://w3layouts.com/" target="_blank"></a> </p>
	    </div>
		<div class="clearfix"> </div>
       </div>
     </div>
<!---->
<!--scrolling js-->
<!--<script src="js/jquery.nicescroll.js"></script>
	<script src="js/scripts.js"></script>-->
	<!--//scrolling js-->
</body>
</html>