
<html>
<head>
  
</head>
<body>
<style>
.img-fluid{
    width: 151px;
    height: 77px;
    border-radius: 90%;
	padding-bottom:-1.23px;
}
#h1 {
    margin-top:-7px;
}
body {
 background-color:#e9ebe4;
}
#h2 {
 float:right;
 margin-top:-110px;
 position:relative;
 margin-right:-0.27px;
}
#h3 {
 float:right;
 margin-top:-72px;
 position:relative;
 margin-right:-1px;
}
#h4 {
 float:right;
 margin-top:-52px;
 position:relative;
 margin-right:-1px;
}
#h5 {
 float:right;
 margin-top:-32px;
 position:relative;
 margin-right:-1.23px;
}
#h6 {
 float:right;
 margin-top:-15px;
 position:relative;
 margin-right:-28px;
}
table {
  border-collapse: collapse;
  width: 950px;
  margin-left:200px;
}

th, td {
  padding: 8px;
  text-align: left;
  border-bottom: 1px solid #ddd;
}


tr:hover {background-color:#f5f5f5;}
.footer {
   position:fixed;
   left: 0;
   bottom: 0;
   width: 100%;
   background-color:#f0f2f2;
   color: white;
   text-align: center;
   color:black;
}
</style>
<div class="container">
<img src="timthumb.png" class="img-fluid" id="img">
<h1 id="h1">INVOICE</h1>
<h2 id="h2">Express Courier Service</h2>
<h5 id="h3">Banashankari</h5>
<h5 id="h4">Bangalore</h5>
<h5 id="h5">India</h5>
<h5 id="h6">560085</h5>
<br>
<hr>
</div>
<div class="container">
  <h2 style="">Bill To:</h2>
  <h4 style="margin-bottom:-12px">Company name:</h4>
  <h5 style="margin-bottom:-12px">Address:</h5>
  <h5 style="margin-bottom:-12px">City:</h5>
  <h5 style="margin-bottom:-12px">Country:</h5>
  <h5 style="margin-bottom:-12px">Pincode:</h5>
  <h5 style="margin-top:-122px;float:right">Invoice id:</h5>
  <span id="" style="float:right;margin-top:-103px;">00012</span>
  <h5 style="margin-top:-77px;float:right">Date:</h5>
  <span id="" style="float:right;margin-top:-57px">23-12-2020</span>
  <h5 style="margin-top:-33px;float:right">Invoice Due Date:</h5>
  <span id="" style="margin-top:-13px;float:right;margin-right:-99px;">24-4-2020</span>
  <br>
  <hr>
</div>
<div class="container">

   
<!-- ----------------------------------------------------------------------- -->
<?php
$conn = mysqli_connect('localhost','root','','expressCourier');
if(!$conn){
    echo "<script>alert('There is some Issue in connection')</script>";
}
else{
   $toName=array();
    $fromName=array();
    $type=array();
    $date=array();
    $amount=array();
$to = $_POST['To'];
$from = $_POST['From'];
$query = "SELECT * FROM booking where date BETWEEN '$to' and '$from' ";
$result = mysqli_query($conn,$query);

while($row = mysqli_fetch_array($result)){
    #print_r($row);
    // echo "<br>";
    array_push($toName,$row['sendTo']);
    array_push($fromName,$row['empId']);
    array_push($type,$row['type']);
    array_push($date,$row['date']);
    array_push($amount,200);
}}

?> 
<table>
    
    <?php             
                     
                        echo "<thead>";
                        echo "<tr class='text-primary'>";

                          echo "<th>To(Id)</th>";

                          echo "<th>From(Id) </th>";

                          echo" <th>Parcel type </th>";

                          echo " <th>Date</th>";

                          echo " <th>Amount</th>";

                        echo "</tr>";

                        echo "</thead>";

                        echo "<tbody>";

                        $size = count($toName);
                        $sum = 0;
                        for($i=0;$i<$size;$i++){
                        echo "<tr class=''>";

                          echo "<td>$toName[$i]</td>";

                          echo "<td>$fromName[$i]</td>";

                          echo "<td>$type[$i]</td>";

                          echo "<td>$date[$i]</td>";

                          echo "<td>$amount[$i]</td>";

                        echo "</tr>";

                        $sum += $amount[$i];
                      }
                      echo "</tbody>";

                      ?>
                        
  
         
         



    </tbody>
  </table>
<br>
<hr>
</div>
<div class="container">
<h3 style="float:right;margin-right:83px";>Sub Total:</h3>
<span id="" style="float:right;margin-right:42px;margin:19px;margin-right:-158px";><?php echo "$sum";?></span>
<h3 style="float:right;margin-right:-84px;margin-top:43px";> Tax:</h3>
<span id="" style="float:right;margin-right:42px;margin:46px;margin-right:-158px";>30%</span>
<h3 style="float:right;margin-right:-84px;margin-top:72px";> Total:</h3>
<span id="" style="float:right;margin-right:42px;margin:76px;margin-right:-158px;margin-bottom:63px";><?php echo "$sum";?></span>
</div>
<div class="footer">
  <p>Terms And Conditions As Applied @ www.ecs.com</p>
</div>
</body>
</html>