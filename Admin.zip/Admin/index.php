<?php
session_start();
if ($_SESSION['adminName'] == "") {
	echo "You must login first";
	header("Location: http://localhost/ExpressCourier/Admin/adminlogin.php");
}

?>


<!DOCTYPE HTML>
<html>

<head>
	<title>ECS</title>
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<meta name="keywords" content="Minimal Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, 
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>

	<style>
		#search {
			margin-top:28px;
		}
		#drop {
			margin: 13px;
		}

		#drop1 {
			margin: 12px;
			width: 12px;
			height: auto;
		}

		.dropdown {
			width: 140px;
		}

		#data {
			margin-bottom: 24px;
		}

		#reciept {
			margin: 12px;
			padding-top: 55px;
			height: 417px;
			margin-right: -234px;
			padding-bottom: 13px;
			width: 656px;
			text-align: center;
		}

		#h1 {
			margin-top: -5.7px;
			margin-bottom: 35px;
		}

		#to {
			float: left;
			position: repeat-x;
			margin: 11px;
			margin-top: 27px;
			padding-left: 0.74px;
			margin-right: 29px;
		}

		#To {
			float: left;
			position: repeat-x;
			margin: -8px;
			margin-top: 36px;
			padding-left: 0.24px;
		}

		#from {
			float: left;
			position: repeat-x;
			margin-left: 1px;
			padding-right: 0.24px;
			margin-top: 27px;
		}

		#track {
			float: left;
			margin: 15px;
			margin-top: 36px;
			padding-left: 0.24px;
			margin-top: -25px;
			margin-left: 880px;
		}

		#From {
			float: left;
			position: repeat-y;
			margin: 1.5px;
			margin-top: 36px;
			padding-left: 5px;
		}

		#sidebar {
			height: auto;
		}

		#main {
			height: 1240px;
		}

		#last {
			margin-left: 17px;
			width: 1001px;
		}

		#h2 {
			margin-top: -14px;
			margin-bottom: 24px;

		}

		#status {
			margin: 13px;
			height: auto;
			margin-right: -74px;
			padding-bottom: 34px;
			padding-left: 1px;
			width: 1002px;
            padding-right:62px;
		}

		#pie {
			margin-top: 12px;
		}
	</style>
	<script type="application/x-javascript">
		addEventListener("load", function() {
			setTimeout(hideURLbar, 0);
		}, false);

		function hideURLbar() {
			window.scrollTo(0, 1);
		}
	</script>
	<link href="css/bootstrap.min.css" rel='stylesheet' type='text/css' />
	<!-- Custom Theme files -->
	<link href="css/style.css" rel='stylesheet' type='text/css' />
	<link href="css/font-awesome.css" rel="stylesheet">
	<script src="js/jquery.min.js"> </script>
	<!-- Mainly scripts -->
	<script src="js/jquery.metisMenu.js"></script>
	<script src="js/jquery.slimscroll.min.js"></script>
	<!-- Custom and plugin javascript -->
	<link href="css/custom.css" rel="stylesheet">
	<script src="js/custom.js"></script>
	<script src="js/screenfull.js"></script>
	<script>
		$(function() {
			$('#supported').text('Supported/allowed: ' + !!screenfull.enabled);

			if (!screenfull.enabled) {
				return false;
			}



			$('#toggle').click(function() {
				screenfull.toggle($('#container')[0]);
			});



		});
	</script>


	<script src="js/pie-chart.js" type="text/javascript"></script>
	<script type="text/javascript">
		$(document).ready(function() {
			$('#demo-pie-1').pieChart({
				barColor: '#3bb2d0',
				trackColor: '#eee',
				lineCap: 'round',
				lineWidth: 8,
				onStep: function(from, to, percent) {
					$(this.element).find('.pie-value').text(Math.round(percent) + '%');
				}
			});

			$('#demo-pie-2').pieChart({
				barColor: '#fbb03b',
				trackColor: '#eee',
				lineCap: 'butt',
				lineWidth: 8,
				onStep: function(from, to, percent) {
					$(this.element).find('.pie-value').text(Math.round(percent) + '%');
				}
			});

		});
	</script>
	<script src="js/skycons.js"></script>
</head>

<body>
	<div id="wrapper">
		<nav class="navbar-default navbar-static-top" role="navigation">
			<div class="navbar-header">
				<button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
					<span class="sr-only">Toggle navigation</span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
				</button>
				<h1> <a class="navbar-brand" href="index.php">ECS</a></h1>
			</div>
			<div class=" border-bottom">
				<div class="full-left">
					<section class="full-top">
						<button id="toggle"><i class="fa fa-arrows-alt"></i></button>
					</section>
					<!--<form class=" navbar-left-right">
						<input type="text" value="Search..." onfocus="this.value = '';" onblur="if (this.value == '') {this.value = 'Search...';}">
						<input type="submit" value="" class="fa fa-search">
					</form>-->
					<div class="clearfix"> </div>
				</div>



				<div class="drop-men">
					<ul class=" nav_1">

						<li class="dropdown" id="drop">
							<a href="adminSignout.php"><span class=" name-caret">logout</span><img src=""></a>
						</li>

					</ul>
				</div>
				<div class="clearfix">

				</div>

				<div class="navbar-default sidebar" role="navigation" id="sidebar">
					<div class="sidebar-nav navbar-collapse">
						<ul class="nav" id="side-menu">

							<li>
								<a href="index.php" class=" hvr-bounce-to-right"><i class="fa fa-dashboard nav_icon "></i><span class="nav-label">Dashboards</span> </a>
							</li>

							<li>
								<a href="Price1.php" class=" hvr-bounce-to-right"><i class="fa fa-inbox nav_icon"></i> <span class="nav-label">Price Table</span> </a>
							</li>

							<li>
								<a href="admin.php" class=" hvr-bounce-to-right"><i class="fa fa-picture-o nav_icon"></i> <span class="nav-label">Add Employee</span> </a>
							</li>

							<li>
								<a href="profile.php" class=" hvr-bounce-to-right"><i class="fa fa-th nav_icon"></i> <span class="nav-label">Profile</span> </a>
							</li>


						</ul>
					</div>
				</div>
		</nav>
		<div class="clearfix"></div>
		<div id="page-wrapper" class="gray-bg dashbard-1">
			<div class="content-main" id="main">

				<div class="banner">
					<h2>
						<a href="index.php">Home</a>
						<i class="fa fa-angle-right"></i>
						<span>Dashboard</span>

					</h2>
				</div>


				<div class="content-top">
					<div class="col-md-4" id="pie" style="font-size:24px; width:350px;">
						<div class="content-top-1">
							<div class="col-md-6 top-content">
								<h5 style="margin-left:0px;">Total Orders</h5>
								<label></label>
							</div>
							<div class="col-md-6 top-content1">
								<!--Making orders dynamic by php    -->
								<div id="demo-pie-1" class="pie-title-center" data-percent="<?php include("pieOrder.php"); ?>"> <span class="pie-value"></span> </div>
							</div>
							<div class="clearfix"> </div>
						</div>
						<div class="content-top-1">
							<div class="col-md-6 top-content">
								<h5>Pending</h5>
								<label></label>
							</div>
							<div class="col-md-6 top-content1">
								<div id="demo-pie-2" class="pie-title-center" data-percent="<?php include("piePending.php"); ?>"> <span class="pie-value"></span> </div>
							</div>
							<div class="clearfix"> </div>
						</div>
					</div>
					<div class="mt-2" id="">
						<form action="Receipt.php" method="POST">
							<div class="col-md-6 content-top-1" id="reciept">
								<h4 style="margin-top:-12px;">Generate Receipt</h4>
								<label id="To">To:</label>
								<input type="date" id="to" name="To" value="to" placeholder="YYYY-MM-DD" required pattern="[0-9]{4}-[0-9]{2}-[0-9]{2}">
								<label id="From">From:</label>
								<input type="date" id="from" name="From" value="from" placeholder="YYYY-MM-DD" required pattern="[0-9]{4}-[0-9]{2}-[0-9]{2}">
								<button type="text" id="search" name="search" class='btn btn-success' >Search</button>
							</div>
						</form>
					</div>
                </div>
               <div class="clearfix"></div>
                 <div class="col-md-9 content-top-1 " id="status">
					<div class="col-md-12 " id="">
						<h4 style="margin-left:413px;">Package Status</h4>

						<table class="table-responsive" style="text-align:center;margin-left:18px;margin-right:22px;font-size:13px;padding-left:30px;padding-right:30px;padding-bottom:20px;">
							<thead>
								<th>
									<p class="text-primary" style="margin-left:13px;">Order Id</p>
								</th>
								<th>
									<p class="text-primary" style="margin-left:6px;">Send To(Id)</p>
								</th>
								<th>
									<p class="text-primary" style="margin-left:6px;">Sent From(Id)
								</th>
								<th>
									<p class="text-primary" style="margin-left:25px;">Address</p>
								</th>
								<th>
									<p class="text-primary" style="margin-left:13px;">Description</p>
									
								</th>
								<th>
									<p class="text-primary" style="margin-left:62px;">Status</p>
								</th>
								<th>
									<p class="text-primary" style="margin-left:62px;">Action</p>
								<th>
									<!-- searching using php-->
							</thead>
							<?php
							$conn = mysqli_connect('localhost', 'root', '', 'expressCourier');




							$query = "select * from booking";
							$run = mysqli_query($conn, $query);
							$count = 0;
							while ($row = mysqli_fetch_array($run)) {

							?>
								<tr>
									<td style="padding-right:15px;padding-left:-6px;"><?= $row['orderId']; ?></td>

									<td style="padding-right:15px;padding-left:3px;"><?= $row['sendTo']; ?></td>
									<td style="padding-right:15px;padding-left:3px;"><?= $row['empId']; ?></td>
									<td style="padding-right:15px;padding-left:3px;padding-bottom:23px;"><?= $row['address']; ?></td>
									<td style="padding-right:15px;padding-left:3px;padding-bottom:13px;"><?= $row['description']; ?></td>
									<td style="padding-left:3px;">

										<?php

										$rx = $row['orderId'];

										if ($row['status'] == '0') {
											echo "<p class='btn btn-warning' style='margin-bottom:13px;'>In process</p>";
										} elseif ($row['status'] == '1') {
											echo "<p class='btn btn-success' style='margin-bottom:10px;'>Approved</p>";
										} elseif ($row['status'] == '2') {
											$del_girlx = $row['v_id'];
											echo "<p class='btn btn-primary small' style='margin-bottom:10px;'>Delivery Boy($del_girlx)</p>";
										} elseif ($row['status'] == '3') {





											$query_remark = "SELECT * from remark where orderId='$rx'";
											$remark_run = mysqli_query($conn, $query_remark);


											while ($row1 = mysqli_fetch_array($remark_run)) {
												if ($row1['r_region'] == '1') {
													$xx = 'Unavailable';
												} elseif ($row1['r_region'] == '2') {
													$xx = 'Return';
												} elseif ($row1['r_region'] == '3') {
													$xx = 'Other';
												}
											}


											$aa =  "<button type='button' class='btn btn-danger' data-toggle='tooltip' data-placement='top' title='$xx'>
											Reason for Undelivered
										</button>";
											echo $aa;
										} elseif ($row['status'] == '4') {
											echo "<p class='btn btn-info' style='margin-bottom:10px;'>Delivered :)</p>";
										}
										?>

									</td>
									<td>
										<div class="">

											<?php if ($row['status'] == 0) {  ?>
												<form action="index.php?orderId=<?= $row['orderId']; ?>" method="post">
													<div class="input-group w-100">
														<select name="delivery" id="" class=""  required style="padding-right:-4px;margin-left:12px;font-size:10px;">
															<option  selected value="">Select delivery boy</option>
															<?php
															$query_delivery = "SELECT * FROM vdeliveryboy";
															$run_delivery = mysqli_query($conn, $query_delivery);
															while ($row1 = mysqli_fetch_array($run_delivery)) {

															?>
																<option value="<?= $row1['v_id']; ?>"><?= $row1['v_id']; ?></option>
															<?php } ?>
														</select>
														<div class="input-group-btn">
															<input type="submit" name="approval<?=  $row['orderId']; ?>" value="Approverd"  class="btn btn-success btn-sm">
															
														</div>
													</div>
													
												</form>

												<?php
												global $order_id;
												$order_id = $row['orderId'];

												if (isset($_POST['approval' . $order_id])) {
													$approval_val = '2';
													  $del_girl = $_POST['delivery'];
													 
													
													 $query = "UPDATE booking SET status='$approval_val' , v_id='$del_girl' WHERE orderId='$order_id'";
													
													
													$run2 = mysqli_query($conn, $query);

													echo "<script>window.open('index.php','_self')</script>";
												}
												?>
											<?php } elseif ($row['status'] == 1) { ?>

												<form action="index.php?orderId=<?= $row['orderId']; ?>" method="post">

													<!-- <input type="submit" name="pending<?= $row['orderId']; ?>" value="Pending" style="border-radius:5px;margin-right:12px;font-size:11px;background-color:#729fc4" class="btn btn-primary" hidden> -->
													<div class="btn-group">

													</div>
										</div>
										</form>
										<?php
												$approval_val = '0';
												$order_id = $row['orderId'];

												if (isset($_POST['pending' . $order_id])) {

													$query = "UPDATE booking SET status='$approval_val' WHERE orderId='$order_id' ";
													$run2 = mysqli_query($conn, $query);

													echo "<script>window.open('index.php','_self')</script>";
												}
										?>
									<?php  } # elseif ($row['status'] == 3) { 
									?>


					</div>
					</td>

					</tr>
				<?php } ?>
				</table>

				</div>
			</div>

		</div>
	</div>
</div>
<div class="clearfix"> </div>
<div class="copy" id="footer">
    <p style="margin-left:12px;"> &copy; 2020 ECS. All Rights Reserved | Design by <a href="http://w3layouts.com/" target="_blank"></a> </p>
</div>
<div class="clearfix"> </div>
	<script src="js/jquery.nicescroll.js"></script>
	<script src="js/scripts.js"></script>
	<!--//scrolling js-->
	<script src="js/bootstrap.min.js"> </script>
</body>

</html>