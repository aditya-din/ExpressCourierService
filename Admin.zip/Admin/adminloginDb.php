<?php
if(isset($_POST['login'])){
    session_start();
    $uname = $_POST['uname'];
    $_SESSION['adminName'] = $uname;
    $pass = $_POST['pass'];
	$conn = mysqli_connect("localhost","root",'','expresscourier');
	$query= "SELECT adminId FROM admin WHERE adminId='$uname' and pass='$pass'";
	$result = mysqli_query($conn,$query);
	$count=0;
	while(mysqli_fetch_array($result)){
		
		$count+=1;
		
    }
    if($count==1){
        header('Location: http://localhost/ExpressCourier/Admin/index.php');
    }
    else{
        header('Location: http://localhost/ExpressCourier/Admin/adminlogin.php');

    }
	


}


?>