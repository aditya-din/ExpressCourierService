<?php
$conn = mysqli_connect("localhost","root","","expressCourier");
if(!$conn)
{
    // echo "Some problem in connecting DB";
//    echo 10;
}
else
{
 $query = "Select * from booking where status = 0";
 $status = array();
 $result = mysqli_query($conn,$query);
 while($row = mysqli_fetch_array($result)){
     array_push($status,$row['status']);
   }
   echo count($status);
}

?>