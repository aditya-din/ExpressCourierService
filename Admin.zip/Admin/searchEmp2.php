<?php
//This file is use by include() function.And session is already started in admin.php
$conn = mysqli_connect('localhost', 'root', '', 'ExpressCourier');
if (!$conn) {
  echo "<script>alert('There is some Issue in connection')</script>";
} else {

  

if(isset($_POST['searchButton'])){

  $value = $_GET['searchInput'];
  
  $empId = array();
  $empName = array();
  $office = array();



  // $query = "SELECT * FROM employeeRegistration WHERE empId = '$value' OR empName = '$value' OR deptName = '$value' ";
  $query = "SELECT * FROM employeeRegistration WHERE empId = '$value' OR empName = '$value' OR deptName = '$value' ";
  $result = mysqli_query($conn, $query);
  while ($row = mysqli_fetch_array($result)) {
    array_push($empId, $row['empId']);
    array_push($empName, $row['empName']);
    array_push($office, $row['office']);
  }


  $count = count($empId);
  for ($i = 0; $i < $count; $i++) {
    echo "<tr>";
    echo "<td> $empId[$i]</td>";
    echo "<td> $empName[$i]</td>";
    echo "<td> $office[$i]</td>";

?>
    <form action="delete.php" method="POST">
      <?php echo "<td> <input type='submit' value ='Delete' name='delete'></td>"; ?>
    </form>
<?php echo "</tr>"; }  ?>


  

  <?php } } ?>