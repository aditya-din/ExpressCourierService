<?php
session_start();
    if(isset($_POST['searchButton'])){
        if(isset($_SESSION['searchEmpId'])){
        $_SESSION['searchEmpId'] = $_POST['searchInput'];
        $_SESSION['jugad']="aditya";
        header("Location: http://localhost/ExpressCourier/Admin/admin.php");
        }
        else{
            $_SESSION['searchEmpId']="aditya";
            $_SESSION['jugad']="aditya";
            header("Location: http://localhost/ExpressCourier/Admin/admin.php");

        }
        
    }
    

?>