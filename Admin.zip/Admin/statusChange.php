<html>
<head>Status change

<meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <title>Employee Admin</title>
  <link rel="stylesheet" href="node_modules/font-awesome/css/font-awesome.min.css" />
  <link rel="stylesheet" href="node_modules/perfect-scrollbar/dist/css/perfect-scrollbar.min.css" />
  <link rel="stylesheet" href="node_modules/flag-icon-css/css/flag-icon.min.css" />
  <link rel="stylesheet" href="css/style.css" />
  <link rel="shortcut icon" href="images/favicon.png" />
  <link rel="stylesheet" type="text/css" href="contact us/bootstrap/css/bootstrap.min.css" />
    <link rel="stylesheet" type="text/css" href="font-awesome/css/font-awesome.min.css" />
    <script type="text/javascript" src="js/jquery-1.10.2.min.js"></script>
    <script type="text/javascript" src="contact us/bootstrap/js/bootstrap.min.js"></script>
	<script src="node_modules/jquery/dist/jquery.min.js"></script>
  <script src="node_modules/popper.js/dist/umd/popper.min.js"></script>
  <script src="node_modules/bootstrap/dist/js/bootstrap.min.js"></script>
  <script src="node_modules/chart.js/dist/Chart.min.js"></script>
 <!-- <script src="node_modules/perfect-scrollbar/dist/js/perfect-scrollbar.jquery.min.js"></script>-->
  <!--<script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyB5NXz9eVnyJOA81wimI8WYE08kW_JMe8g&callback=initMap" async defer></script>-->
  <script src="js/off-canvas.js"></script>
  <script src="js/hoverable-collapse.js"></script>
  
  
  <style>   /* Some css for table */
table{ 
border-collapse:separate; 
border-spacing: 0 15px; 
} 
th{ 
background-color: #4287f5; 
color: white; 

} 
th{ 
width: 130px; 
text-align: center; 
border: 1px solid black; 
padding: 2px;
}

  
  
  
  </style>
  
</head>
<body>
    <!-- <h3>changeing the status to pending and approved</h3>
    <br>
    <button type="button" name = "approved">Approved</button>
    <br>
    <button type="button" name = "pending">Pending</button> -->
    <?php
$conn = mysqli_connect('localhost','root','','courier');
if(!$conn){
    echo "Some error";
}
else{
    $order=array();
    $toname=array();
    $empId=array();
    $oredrOn=array();
    $contact=array();
    $desc =array();
    $staus = array();

    //echo "Connected  \n";
    $query = "select * from booking";
    $result = mysqli_query($conn,$query);
    while($row = mysqli_fetch_array($result)){
      array_push($order,$row['orderId']);
      array_push($toname,$row['toname']);
      array_push($empId,$row['sendTo']);
      array_push($oredrOn,$row['date']);
      array_push($contact,$row['contact']);
      array_push($desc,$row['description']);
      array_push($staus,$row['status']);

    }
   
  
}
?>

<table class="table center-aligned-table">
                    <thead>
                      <tr class="text-primary">
                        <th>Order Id</th>
                        <th>To </th> <!-- to employee  -->
                         <th> Emp. Id.</th> 
                        <th>Ordered On</th> <!-- Date  -->
                        <th>Contact</th>
                        <th>Description</th>
                        <th>Status</th>

                        <!-- 
<form action='#' method='POST'>  
    </form>

                        -->
                        <th>Change </th>
                      </tr>
                    </thead>
                    <tbody>
                      <tr class="">
                      <?php 
                      $size = count($order);
                      for($i=0;$i<$size;$i++){
                        echo " 
                               <tr class=''>";
                        echo "<td class='$i'>$order[$i]</td>";
                        echo "<td class='$i'>$toname[$i]</td>";
                        echo "<td class='$i'>$empId[$i]</td>";
                        echo "<td class='$i'>$oredrOn[$i]</td>";
                        echo "<td class='$i'>$contact[$i]</td>";
                        echo "<td class='$i'>$desc[$i]</td>";
                        echo "<td class='$i'>$staus[$i]</td>";
        
                        echo "
                       
                            <td> 
                                
                                <button class='$i' name='approved' onclick='app( $order[$i])'>Approved</button>

                            </td>
                            <td>
                                <button class='$i' name='pending' onclick='pen()'>Pending</button>
                            </td> 
                        " ;
                        echo " </tr>";
                        
                      }
                      ?>
</tbody>
</table>
<!-- After clicking button. Changing status -->
<script>
function app(ord){
    
   alert("Ord is triggred",ord);
}


</script>


   
</body>

</html>
<?php
$num = 123;
echo gettype($num);
echo gettype(strval($num ));


?>