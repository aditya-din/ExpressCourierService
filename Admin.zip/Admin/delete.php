<?php
session_start();
$conn = mysqli_connect('localhost','root','','expresscourier');
if(!$conn){
    echo "<script>alert('There is some Issue in connection')</script>";
}
else{
$value = $_SESSION['searchEmpId'];
$query = "DELETE FROM employeeRegistration WHERE empId = '$value' ";
mysqli_query($conn,$query);
header("Location: http://localhost/ExpressCourier/Admin/admin.php");
}?>