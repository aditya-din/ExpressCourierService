<?php
session_start();
echo "Aditya";
$_SESSION['logout'] == "";
session_destroy();
header("location: http://localhost/ExpressCourier/Admin/adminlogin.php");

?>