<!-- Create a web page for receipt -->
<?php
$conn = mysqli_connect('localhost','root','','courier');
if(!$conn){
    echo "<script>alert('There is some Issue in connection')</script>";
}
else{
$to = $_POST['To'];
$from = $_POST['From'];
$query = "SELECT * FROM booking where date BETWEEN '$to' and '$from' ";
$result = mysqli_query($conn,$query);

while($row = mysqli_fetch_array($result)){
    print_r( $row);
    echo "<br>";
}
// echo "from to "."$to";
// echo "<br>";
// echo "from from"."$from";

}


// echo phpinfo();

?>