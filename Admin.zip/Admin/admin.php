<?php
session_start();
if ($_SESSION['adminName'] == "") {
	echo "You must login first";
	header("Location: http://localhost/ExpressCourier/Admin/adminlogin.php");
}

?>

<!DOCTYPE HTML>
<html>

<head>
	<title>ECS</title>
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<meta name="keywords" content="Minimal Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, 
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
	<script type="application/x-javascript">
		addEventListener("load", function() {
			setTimeout(hideURLbar, 0);
		}, false);

		function hideURLbar() {
			window.scrollTo(0, 1);
		}
	</script>
	<link href="css/bootstrap.min.css" rel='stylesheet' type='text/css' />
	<!-- Custom Theme files -->
	<link href="css/style.css" rel='stylesheet' type='text/css' />
	<link href="css/font-awesome.css" rel="stylesheet">
	<script src="js/jquery.min.js"> </script>
	<!-- Mainly scripts -->
	<script src="js/jquery.metisMenu.js"></script>
	<!--<script src="js/jquery.slimscroll.min.js"></script>-->
	<!-- Custom and plugin javascript -->
	<link href="css/custom.css" rel="stylesheet">
	<script src="js/custom.js"></script>
	<script src="js/screenfull.js"></script>
	<script>
		$(function() {
			$('#supported').text('Supported/allowed: ' + !!screenfull.enabled);

			if (!screenfull.enabled) {
				return false;
			}



			$('#toggle').click(function() {
				screenfull.toggle($('#container')[0]);
			});



		});
	</script>
	<!--skycons-icons-->
	<script src="js/skycons.js"></script>
	<!--//skycons-icons-->
	<style>
		#drop {
			margin: 13px;
		}

		#drop1 {
			margin: 12px;
			width: 12px;
			height: auto;
		}

		.dropdown {
			width: 140px;
		}
	</style>
</head>

<body>
	<div id="wrapper">

		<!----->
		<nav class="navbar-default navbar-static-top" role="navigation">
			<div class="navbar-header">
				<button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
					<span class="sr-only">Toggle navigation</span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
				</button>
				<h1 id="H1"> <a class="navbar-brand" href="index.php" id="nav"><strong>ECS</strong></a></h1>
			</div>
			<div class=" border-bottom">
				<div class="full-left">
					<section class="full-top">
						<button id="toggle"><i class="fa fa-arrows-alt"></i></button>
					</section>
					<div class="clearfix" id="clear"> </div>
				</div>
				<div class="drop-men">
					<ul class=" nav_1">
						<li class="dropdown" id="drop">
							<a href="logout.php"><span class=" name-caret">logout</span><img src=""></a>

						</li>

					</ul>
				</div>
				<div class="clearfix">
				</div>
				<div class="navbar-default sidebar" role="navigation">
					<div class="sidebar-nav navbar-collapse">
						<ul class="nav" id="side-menu">

							<li>
								<a href="index.php" class=" hvr-bounce-to-right"><i class="fa fa-dashboard nav_icon "></i><span class="nav-label">Dashboards</span> </a>
							</li>
							<li>
								<a href="Price1.php" class=" hvr-bounce-to-right"><i class="fa fa-inbox nav_icon"></i> <span class="nav-label">Price Table</span> </a>
							</li>
							<li>
								<a href="admin.php" class=" hvr-bounce-to-right"><i class="fa fa-picture-o nav_icon"></i> <span class="nav-label">Add Employee</span> </a>
							</li>
							<li>
								<a href="profile.php" class=" hvr-bounce-to-right"><i class="fa fa-th nav_icon"></i> <span class="nav-label">Profile</span> </a>
							</li>
						</ul>
					</div>
				</div>
		</nav>
		<style>
			#Well1 {
				height: 763px;
				margin-left: 375px;
				margin-top: 17px;
				margin-bottom: 30px;
				width: 450px;
				margin-left: 2px;
				margin-right: -42px;
			}

			body {
				background-color: LightGray;
			}

			#back {
				align: justify;
			}

			#well2 {
				width: 200px;
				margin: 37px;
			}

			#frm {
				margin-top: 3px;
				margin-right: 32px;
				margin-left: 173px;
			}

			#tab {
				margin-left: 164px;
			}
		</style>
		<div id="page-wrapper" class="gray-bg dashbard-1">
			<div class="content-main">

				<!--banner-->
				<div class="banner">
					<h2>
						<a href="index.php">Home</a>
						<i class="fa fa-angle-right"></i>
						<span>Dashboard</span>
					</h2>
				</div>
				<!--//banner-->

				<div class="container-fluid">
					<div class="col-sm-4">
						<div class="well" id="Well1">
							<form action="admin_dashDb.php" method="POST">
								<h2>Add Employee</h2>
								<br>
								<div class="form-group">
									<label for="empid">Employee Id</label>
									<input type="text" class="form-control" id="empid" placeholder="Enter empid" name="empid" value=<?php $_SESSION['NewEmpId'] = uniqid('ECS'); ?>>
									<span id="eid" class="text-danger"></span>
								</div>
								<div class="form-group">
									<label for="empname">Employee Name</label>
									<input type="text" class="form-control" id="empname" placeholder="Enter employee name" name="empname">
									<span id="ename" class="text-danger"></span>
								</div>
								<div class="form-group">
									<label for="dept">Department Name</label>
									<input type="text" class="form-control" id="dept" placeholder="Enter department name" name="deptname" value=<?php $_SESSION['NewPass'] = "password"; ?>>
									<span id="dep" class="text-danger"></span>
								</div>
								<div class="form-group">
									<label for="dept">Contact</label>
									<input type="text" class="form-control" id="contact" placeholder="Enter contact detail" name="contact">
									<span id="contact1" class="text-danger"></span>
								</div>
								<div class="form-group">
									<label for="dept">Address</label>
									<input type="text" class="form-control" id="address" placeholder="Enter address detail" name="address">
									<span id="adds" class="text-danger"></span>
								</div>
								<div class="form-group">
									<label for="Office">Office Name</label>
									<select id="off_id" name="office">
										<option value="office1">office1</option>
										<option value="office2">office2</option>
										<option value="office3">office3</option>
										<option value="office4">office4</option>
									</select>
								</div>
								<div class="form-group">
									<label for="password">Password</label>
									<input type="password" class="form-control" id="pass" placeholder="Enter Employee Password" name="pass" style="align:justify" ;>
									<span id="Pass" class="text-danger"></span>
								</div>

								<button type="submit" class="btn btn-primary" name="submit" onclick="return myfunction()">Submit</button>
						</div>
					</div>
					</form>

					<div class="col-sm-6" id="well2">
						<div class="container" id="frm">
						<!-- ------------------------------------------------------------------ -->
						<form action="" method="GET">
			<input type="text" id="myInput" placeholder="Search by Employee Id" title="Type in a name" name = "searchInput" autocomplete="off">
			<button type="submit"  class="btn btn-primary" name ="searchButton">Submit</button>
        </form>

		</div>
		<table class="table" id="tab">
            <thead>
              <th>Employee Id</th>
              <th>Employee Name</th>
              <th>Office Name</th>
			  <th>Action</th>

			  
			</thead>

			<?php
              $conn = mysqli_connect('localhost','root','','expresscourier');
			 if(isset($_GET['searchInput'])) {
			  $value = $_GET['searchInput'];
              $empId = array();
              $empName = array();
              $office = array();
            
            
            
            // $query = "SELECT * FROM employeeRegistration WHERE empId = '$value' OR empName = '$value' OR deptName = '$value' ";
            $query = "SELECT * FROM employeeRegistration WHERE empId = '$value' OR empName = '$value' OR deptName = '$value' ";
            $result = mysqli_query($conn,$query);
            while($row = mysqli_fetch_array($result)){
                array_push($empId,$row['empId']);
                array_push($empName,$row['empName']);
                array_push($office,$row['office']);
            }


            $count = count($empId);
            for($i=0;$i<$count;$i++)
            {
                
                echo "<tr>";
                echo "<td> $empId[$i]</td>";
                echo "<td> $empName[$i]</td>";
                echo "<td> $office[$i]</td>";
            
?>

                    <form action="delete.php" method="POST">
                    <?php echo "<td> <input type='submit' value ='Delete' name='delete'></td>";?>
                    </form>
                    <?php   
                       echo "</tr>";
                      
            } } ?>

						</table>
					</div>
				</div>
				<!-- ---------------------------------- -->

				<!--content-->
				<div class="copy">
					<p> &copy; 2020 ECS. All Rights Reserved | Design by <a href="http://w3layouts.com/" target="_blank"></a> </p>
				</div>
			</div>
			<div class="clearfix"> </div>
		</div>
		<!-- validation--->
		<script type="text/javascript">
			function myfunction() {
				var empid = document.getElementById('empid').value;
				var empname = document.getElementById('empname').value;
				var deptname = document.getElementById('dept').value;
				var contact = document.getElementById('contact').value;
				var pass = document.getElementById('pass').value;
				var addr = document.getElementById('address').value;

				if (empid == "") 
               {
	               document.getElementById('eid').innerHTML = "** please fill the empid field";
	               return false;
               }

                var exp = /^[a-z0-9]+$/;  <!--/^[A-Za-z0-9]+$/g->
                var result = exp.test(empid);	
                if(result)
             {
                document.getElementById('eid').innerHTML="**empid must be alphanumeric(Amp123)";
                return false;
             }
               len = empid.length;
               for(var i=0;i<len;i++){
            if (empid[i]==" "){
                document.getElementById('eid').innerHTML="**space is not allowed";
                return false;
            }
          }			
            var empid = document.getElementById('empid').value;
            for (i = 0; i < empid.length; i++) {
	         ch = empid.charAt(i);
            if (!(ch >= 'A' && ch <= 'Z') && !(ch >= 'a' && ch <= 'z') && !(ch >= '0' && ch <= '9')) {
	              document.getElementById('eid').innerHTML = "**empid must be alphabets and numbers";
	          return false;
	        }
          }	
				if (empname == "") {
					document.getElementById('ename').innerHTML = "** please fill the empname field";
					return false;
				}
				var empname = document.getElementById('empname').value;
				for (i = 0; i < empname.length; i++) {
					ch = empname.charAt(i);
					if (!(ch >= 'A' && ch <= 'Z') && !(ch >= 'a' && ch <= 'z') && !(ch == ' ')) {
						document.getElementById('ename').innerHTML = "**empname must be alphabets not numeric";
						return false;
					}
				}
				if(!isNaN(empname)) {
					document.getElementById('ename').innerHTML = "**empname must be alphabets not numeric";
					return false;
				}
				if(empname.length < 3)
				{
					document.getElementById('ename').innerHTML = "** empname length must be greater than 3 character";
					return false;
				}
				if(empname.length > 40)
				{
					document.getElementById('ename').innerHTML = "** empname length cannot be greater than 40 character";
					return false;
				}
				var exp = /^[\W]+$/;
				var result = exp.test(empname);
				if (result) {
					document.getElementById('ename').innerHTML = "** special character are not allowed";
					return false;
				}
               if(deptname == "")
            {
                document.getElementById('dep').innerHTML = "** please fill the department name field";
                return false;
            }
                 var deptname = document.getElementById('dept').value;
                for (i = 0; i < deptname.length; i++) {
	            ch = deptname.charAt(i);
              if (!(ch >= 'A' && ch <= 'Z') && !(ch >= 'a' && ch <= 'z') && !(ch == ' ')) {
	             document.getElementById('dep').innerHTML = "**deptname must be alphabets not numeric";
	             return false;
	           }
              }
               if(deptname.length < 3 )
           {
                document.getElementById('dep').innerHTML = "**deptname must be greater than 3 character";
	            return false;
            }
               if(deptname.length > 20 )
              {
                    document.getElementById('dep').innerHTML = "**deptname must be less than 20 character";
	                return false;
              }
				if (contact == "") {
					document.getElementById('contact1').innerHTML = "** please fill the contact field";
					return false;
				}
				if (contact.length < 10) {
					document.getElementById('contact1').innerHTML = "** mobile number must be 10 digits only";
					return false;
				}
				if (contact.length > 10) {
					document.getElementById('contact1').innerHTML = "** mobile number must be 10 digits only";
					return false;
				}
				if (isNaN(contact)) {
					document.getElementById('contact1').innerHTML = "** mobile number must be numeric";
					return false;
				}
				if ((contact.charAt(0) != 7) && (contact.charAt(0) != 8) && (contact.charAt(0) != 9) && (contact.charAt(0) != 6)) {
					document.getElementById('contact1').innerHTML = "** mobile number must be start with 6,7,8 and 9";
					return false;
				}
				var exp = /^[\W]+$/;
				var result = exp.test(contact);
				if (result) {
					document.getElementById('contact1').innerHTML = "** special character are not allowed";
					return false;
				}
				if(addr == ""){
					document.getElementById('adds').innerHTML = "** please fill the address field";
					return false;
				}
				var exp = /^[\W]+$/;
				var result = exp.test(addr);
				if (result) {
					document.getElementById('adds').innerHTML = "** charcter such as !@#$%^&* are not allowed";
					return false;
				}
				if(addr.length < 3)
				{
					document.getElementById('adds').innerHTML = "** address length must be greater than 3 character";
					return false;
				}
				if(addr.lenght > 20)
				{
					document.getElementById('adds').innerHTML = "** address length cannot be greater than 20 character";
					return false;
				}
				if (pass == "") {
					document.getElementById('Pass').innerHTML = "** please fill the password field";
					return false;
				}
				if(pass.length < 5)
				{
					document.getElementById('Pass').innerHTML = "**password length must be greater than 5 characters or digits";
					return false;
				}
				if(pass.length > 11)
				{
                    document.getElementById('Pass').innerHTML = "**password length must be smaller than 11 characters or digits";
					return false;
				}
				var exp = /^[\W]+$/;
				var result = exp.test(pass);
				if (result) {
					document.getElementById('Pass').innerHTML = "** special character are not allowed";
					return false;
				}

			}
		</script>
		<!---->
		<!--scrolling js-->
		<!--<script src="js/jquery.nicescroll.js"></script>-->
		<!--<script src="js/scripts.js"></script>-->
		<!--//scrolling js-->
		<script src="js/bootstrap.min.js"> </script>
</body>

</html>