<!-- employee will be added here -->
<?php

use PhpMyAdmin\Scripts;

#session_start();
$conn = mysqli_connect("localhost","root","","ExpressCourier");
if(!$conn)
{
    echo "Some problem in connecting DB";
}
else{
    if(isset($_POST['submit'])){
        $empId = $_POST['empid'];
        $empName = $_POST['empname'];
        $deptName = $_POST['deptname'];
        $contact = $_POST['contact'];
        $office = $_POST['office'];
        $address = $_POST['address'];
       
       
        $pass = $_POST['pass'];
        //echo $empId." pass= ".$pass.' dept = '.$deptName.' empname='.$empName;
        $query = "INSERT INTO employeeRegistration(empId, empName, deptName, pass, office, contact,address) VALUES ('$empId','$empName','$deptName','$pass','$office','$contact','$address')";
        mysqli_query($conn,$query);
        // echo "<script> alert('Employee is added successfully'); </script>";
        echo "<script>alert('Employee Register succesfully')</script>";
        header ("location:admin.php");
        #echo "";
    } //write code for checking is employee is already available or not.
      // after reloading redundent data is going.
}


?>

