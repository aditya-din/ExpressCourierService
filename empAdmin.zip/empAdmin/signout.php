<?php #logout here.
session_start();
$_SESSION['empId']="";
session_destroy();
header("Location: http://localhost/ExpressCourier/homePage.php");

?>