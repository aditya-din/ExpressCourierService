
<?php 
 $conn = mysqli_connect("localhost","root","","ExpressCourier"); 
        if(isset($_POST['direction'])){
            $to = $_POST['to'];
            $from = $_POST['from'];
            
            
            
            header("Location:https://www.google.com/maps/dir/".$to."/".$from." ");
            #header("Location:track.php");

            }
          
      ?>
<!DOCTYPE html>
<html lang="en">

<head>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <title>Employee Admin</title>
  <link rel="stylesheet" href="node_modules/font-awesome/css/font-awesome.min.css" />
  <link rel="stylesheet" href="node_modules/perfect-scrollbar/dist/css/perfect-scrollbar.min.css" />
  <link rel="stylesheet" href="node_modules/flag-icon-css/css/flag-icon.min.css" />
  <link rel="stylesheet" href="css/style.css" />
  <link rel="shortcut icon" href="images/favicon.png" />
  <link rel="stylesheet" type="text/css" href="bootstrap/css/bootstrap.min.css" />
    <link rel="stylesheet" type="text/css" href="font-awesome/css/font-awesome.min.css" />

    <script type="text/javascript" src="js/jquery-1.10.2.min.js"></script>
    <script type="text/javascript" src="bootstrap/js/bootstrap.min.js"></script>
	<!--===============================================================================================-->
	<link rel="icon" type="image/png" href="book/images/icons/favicon.ico"/>
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="book/vendor/bootstrap/css/bootstrap.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="book/fonts/font-awesome-4.7.0/css/font-awesome.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="book/vendor/animate/animate.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="book/vendor/css-hamburgers/hamburgers.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="book/vendor/select2/select2.min.css">
<!--==============================================================================================-->
	<link rel="stylesheet" type="text/css" href="book/css/util.css">
	<link rel="stylesheet" type="text/css" href="book/css/main.css">
  </head>
  <style>
  #fluid{
    padding-left:230px;
	position:absolute;
  }
  </style>
  <body>
  <div class="container-fluid" >
      <div class="row row-offcanvas row-offcanvas-right">
        <!-- partial:partials/_sidebar.html -->
        <nav class="bg-white sidebar sidebar-offcanvas" id="sidebar">
          <div class="user-info">
            <img src="images/face.jpg" alt="" width="90" height="90">
            <p class="name"></p>
            <p class="designation"></p>
            <span class="online"></span>
          </div>
          <ul class="nav">
            <li class="nav-item active">
              <a class="nav-link" href="index.php">
                <img src="images/icons/1.png" alt="">
                <span class="menu-title">Dashboard</span>
              </a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="book1.php">
                <img src="images/icons/005-forms.png" alt="">
                <span class="menu-title">Booking</span>
              </a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="track.php">
                <img src="images/icons/4.png" alt="">
                <span class="menu-title">Track</span>
              </a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="contact.html">
                <img src="images/icons/5.png" alt="">
                <span class="menu-title">Contact Us</span>
              </a>
            </li>
            
          </ul>
        </nav>
        <!-- partial -->
      </div>
    </div>
    
	<div class="container-fluid" id="fluid">
    <div class="row">
      <div class="col-lg-4"></div>
      <div class="col-lg-4">
        <div class="card mt-5">
          <div class="card-header">Get Direction</div>
          <div class="card-body">
            <form action="track.php" method="post">
              <div class="form-group">
                <label for="">From</label>
                <select name="from" class="form-control" id="" required>
                  <option selected disabled="">Select City</option>

                  <!-- loop start -->
                  <option value="delhi">Delhi</option>
                  <!-- end loop -->
                </select>
              </div>
              <div class="form-group">
                <label for="to">To</label>
                <select name="to" class="form-control" id="" required>
                  <option selected disabled="">Select City</option>
                  <!-- loop start -->
                  <option value="patna">Patna</option> 
                  <!-- end loop -->
                </select>
              </div>
              <!-- https://www.google.co.in/maps/dir/?from=purnea&to=patna -->
      
            <div class="from-group">
              <label for=""></label>
              <input type="submit" value="Get direction" name="direction" class="btn btn-success">
            </div>

    </form>
      
      

          </div>
        </div>
      </div>

  <div class="col-lg-4">
    

 <!-- <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3888.583105385612!2d77.53232771464477!3d12.934494790880219!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3bae3e468d8d36d3%3A0x694d74f6ac640acf!2sPES%20University!5e0!3m2!1sen!2sin!4v1586008544157!5m2!1sen!2sin" class="w-100" height="700px" frameborder="0" style="border:0;" allowfullscreen="" aria-hidden="false" tabindex="0"></iframe> -->
  </div>

    </div>
	
	</div>
  </body>
  </html>