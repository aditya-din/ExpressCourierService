<?php
session_start();
$conn = mysqli_connect('localhost', 'root', '', 'expresscourier');
if (!$conn) {
    echo "Some problem in connection of DB";
} else {
    // echo "connection successful\n";
    if (isset($_POST['submitx'])) {
        //echo "<script> alert('connected to expressCourier') </script>";

        $_SESSION['orderId'] = "ORD".uniqid(); //creating unique Order Id
        $orderId = $_SESSION['orderId']; //storing order id into variable
        $fromEmpId = $_SESSION['empId']; //storing employee id into fromEmpId variable
       
        $empName = $_POST['empname'];//receiver employee name
        $toEmpId = $_POST['toemp']; //receiver employee id
        $address = $_POST['address']; //his/her office address
       // $date = $_POST['date']; //date on which it is sending
        $contact =(int)$_POST['contact']; //receiver contact number
        $description  = $_POST['description'];  //decribing about the product
        $parcelType = $_POST['parcel_type']; //which type of parcel it is

       
    //     echo "Order Id= ".$orderId;
    //     echo "<br>";
    //     echo "Emp Id = ".$_SESSION['empId'];
    //     echo "<br>";
        
    //     echo "empname = ".$_POST['empname'];
    //     echo "<br>";
    //     echo "To emp= ".$_POST['toemp'];
    //     echo "<br>";
    //     echo "address =".$_POST['address'];
    //     echo "<br>";
    //   //  echo "date = ".$_POST['date'];
    //     echo "<br>";
    //     echo "contact = ".$contact;
    //     echo "<br>";
    //     echo "description = ".$_POST['description'];
    //     echo "<br>";
    //     echo "parcel Type =".$_POST['parcel_type'];
    //     $con = 12345;
       

        $query = "INSERT INTO booking (sendTo, empId, address , description, type, orderId, contact,toname) VALUES ('$toEmpId','$fromEmpId','$address','$description','$parcelType','$orderId','$contact','$empName')";
        
        $query2 = "Select * from booking where orderId= '$orderId' ";
        
        
        
        $request = mysqli_query($conn,$query);
        $result2 = mysqli_query($conn,$query2);


        while ($row = mysqli_fetch_array($result2)) {
            $SorderId = $row['orderId'];
            $SempId  = $row['empId'];
            $Sstatus = $row['status'];
            $Sdescription = $row['description'];
            $Stype = $row['type'];
        }
        echo "<br>";
        echo "<script>
        window.alert('Your item has been booked');
        window.location.href='http://localhost/ExpressCourier/empAdmin/index.php';


        // </script>";

        //header ("Location: http://localhost/ExpressCourier/empAdmin/index.php");
        // echo "<script>alert('Item booked') </script>";
        //echo "\n check data base now ";
        //$_SESSION['ordered'] = 1;    
    } else {
        echo "some problem is there in ...";
    }
}
