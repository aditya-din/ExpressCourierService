<?php
session_start();
if(isset($_POST['submit'])){
    $empId = $_SESSION['empId']; // Taking EmpId while login only.
    $BAG = $_POST['experience']; //from form
    $comment = $_POST['comments'];//from form
    $email = $_POST['emailid'];//from form
    //$ordid = "ORD".uniqid(); //creating unique order id for employee.
    //echo 'empId = '.$empId.' experience = '.$BAG."comments = ".$comment." email = ".$email;
    $conn = mysqli_connect('localhost','root','','expressCourier');
    if(!$conn){
        echo "Some problem in connection with DataBase ";

    }
    else{
        $query = "INSERT INTO feedback(empId, BAG, comment, email) VALUES ('$empId','$BAG','$comment','$email')";
        mysqli_query($conn,$query);
        //echo "Check db";
        header ("Location: http://localhost/ExpressCourier/empAdmin/index.php");
    }

}
else{
    header ("Location: http://localhost/ExpressCourier/empAdmin/index.php");
}






?>