<?php
$conn = mysqli_connect("localhost", "root", "", "expressCourier");
session_start();
$profilePic = $_SESSION['$profilePic'];
if ($_SESSION['empId'] == "") {
  echo "<script>alert('You must login first')</script>";
  header("Location: http://localhost/ExpressCourier/login/loginIndex.php");
}

?>
<!DOCTYPE html>
<html lang="en">

<head>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <title>Employee Admin</title>
  <link rel="stylesheet" href="node_modules/font-awesome/css/font-awesome.min.css" />
  <link rel="stylesheet" href="node_modules/perfect-scrollbar/dist/css/perfect-scrollbar.min.css" />
  <link rel="stylesheet" href="node_modules/flag-icon-css/css/flag-icon.min.css" />
  <link rel="stylesheet" href="css/style.css" />
  <link rel="shortcut icon" href="images/favicon.png" />
  <link rel="stylesheet" type="text/css" href="bootstrap/css/bootstrap.min.css" />
  <link rel="stylesheet" type="text/css" href="font-awesome/css/font-awesome.min.css" />
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js"></script>

  <script type="text/javascript" src="js/jquery-1.10.2.min.js"></script>
  <script type="text/javascript" src="bootstrap/js/bootstrap.min.js"></script>
  <!--===============================================================================================-->
  <link rel="icon" type="image/png" href="book/images/icons/favicon.ico" />
  <!--===============================================================================================-->
  <link rel="stylesheet" type="text/css" href="book/vendor/bootstrap/css/bootstrap.min.css">
  <!--===============================================================================================-->
  <link rel="stylesheet" type="text/css" href="book/fonts/font-awesome-4.7.0/css/font-awesome.min.css">
  <!--===============================================================================================-->
  <link rel="stylesheet" type="text/css" href="book/vendor/animate/animate.css">
  <!--===============================================================================================-->
  <link rel="stylesheet" type="text/css" href="book/vendor/css-hamburgers/hamburgers.min.css">
  <!--===============================================================================================-->
  <link rel="stylesheet" type="text/css" href="book/vendor/select2/select2.min.css">
  <!--==============================================================================================-->
  <link rel="stylesheet" type="text/css" href="book/css/util.css">
  <link rel="stylesheet" type="text/css" href="book/css/main.css">
</head>
<style>
  #sidebar {
    width: 200px;
    height: 790px;
  }

  #contact1 {
    height: 790px;
    width: 1060px;
    margin-left: 0px;
    padding-left: 67px;
    padding-top: 15px;
    padding-bottom: 100px;
    margin-bottom: 0px;
    background-color: teal;
    float: right;
  }
  #bookingx {
    height:752px;
  }
</style>

<body>
  <div class="container-fluid">
    <div class="row row-offcanvas row-offcanvas-right">
      <!-- partial:partials/_sidebar.html -->
      <nav class="bg-white sidebar sidebar-offcanvas" id="sidebar">
        <div class="user-info">
      
          <img src="<?php  echo $profilePic;?>" alt="" width="90" height="90">
          <p class="name"></p>
          <p class="designation"></p>
          <span class="online"></span>
        </div>
        <ul class="nav">
          <li class="nav-item active">
            <a class="nav-link" href="index.php">
              <img src="images/icons/1.png" alt="">
              <span class="menu-title">Home</span>
            </a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="book1.php">
              <img src="images/icons/005-forms.png" alt="">
              <span class="menu-title">Booking</span>
            </a>
          </li>
          <!--  -->
          <!--<li class="nav-item">
            <a class="nav-link" href="contact.html">
              <img src="images/icons/5.png" alt="">
              <span class="menu-title">Contact Us</span>
            </a>
          </li>-->

        </ul>
      </nav>
    </div>
  </div>
  </div>
  <div class="container-contact1" id="contact1">
    <div class="contact1-pic js-tilt" data-tilt>
      <img src="book/images/img-01.png" alt="IMG">
    </div>



    <?php
    if (isset($_POST['toemp'])) {


      $empidval = $_POST['toemp'];
      $query_empid = "SELECT * from employeeregistration where empId='$empidval'";
      $run_d = mysqli_query($conn, $query_empid);
      if (mysqli_num_rows($run_d) > 0) {
        while ($row = mysqli_fetch_array($run_d)) {
          $emp_name = $row['empName'];
          $emp_address = $row['address'];
          $emp_contact = $row['contact'];
        }
      }
    }


    ?>
    <div class="contact1-form validate-form">
    <form class="contact1-form validate-form" method="POST" id="bookingx">
      <span class="contact1-form-title">
        Booking Details
      </span>

      <!-- -----------For choosing Employee--------------------------- -->
      <div class="wrap-input1 validate-input">
        <!-- <input class="" type="text" name="toemp" placeholder="empid" id="" required=""> -->
        <select name="toemp" class='input1' id="empId" onchange="this.form.submit()" style="border-radius:20px;width:390px;color:gray;height:50px;">
          <option value="che">Choose employer</option>
          <?php if (!empty($empidval)) {  ?>
            <option value="<?= $empidval; ?>" selected> <?= $empidval; ?> </option>
            <option disabled>--------------------------------------------</option>
            <option disabled>--------------------------------------------</option>
          <?php } ?>

          <?php
          $query = "SELECT * FROM employeeregistration";
          $run = mysqli_query($conn, $query);
          $count = 0;
          while ($row = mysqli_fetch_array($run)) {
          ?>
            <?php if ($_SESSION['empId'] == $row['empId']) { ?>

              <option value=<?= $row['empId'] ?> hidden> <?= $row['empId'] ?> </option>


            <?php } else { ?>
              <option value='<?= $row['empId'] ?>'> <?= $row['empId'] ?> </option>
            <?php }  ?>
          <?php } ?>
        </select>
        <span id="emp" class="text-warning"></span>
      </div>
      <!-- ................................................................. -->



      <!-- -----------------------Choosing Employee Name-------------------------- -->

      <div class="wrap-input1 validate-input">
        <input class="input1" type="text" name="empname" placeholder="Employee Name" id="empname" value="<?php if (!empty($emp_name)) {
                                                                                                            echo "$emp_name";
                                                                                                          } ?>">
        <span id="ename" class="text-warning"></span>
      </div>
      <!-- ................................................................. -->


      <!-- -----------------------Choosing Document type-------------------------- -->


      <!-- ................................................................. -->


      <!-- -----------------------Choosing Address-------------------------- -->
      <div class="wrap-input1 validate-input">
        <input class="input1" type="text" name="address" placeholder="address" id="address" value="<?php if (!empty($emp_address)) {
                                                                                                      echo "$emp_address";
                                                                                                    } ?>">
        <span id="addr" class="text-warning"></span>
      </div>
      <!-- ................................................................. -->

      <!-- -----------------------Choosing Contact-------------------------- -->
      <div class="wrap-input1 validate-input">
        <input class="input1" type="text" name="contact" placeholder="contact" id="contact" value="<?php if (!empty($emp_contact)) {
                                                                                                      echo "$emp_contact";
                                                                                                    } ?>">
        <span class="shadow-input1"></span>
        <span id="no" class="text-warning"></span>
      </div>
      <!-- ................................................................. -->

      <div class="wrap-input1 validate-input" style="border-radius:20px;width:390px;color:gray;height:50px;">
        <!--<input class="input1" type="" name="email" placeholder="Email">-->
        <select name="parcel_type" class="input1" style="border-radius:20px;width:390px;color:gray;height:50px;">
          <option value="Choose Parcel type">Choose Parcel Type</option>
          <option value="documents">documents</option>
          <option value="parcel">parcel</option>
          <option value="computer parts">computer parts</option>
        </select>
        <!--<span class="shadow-input1"></span>-->
      </div>
      <!-- -----------------------Choosing Description-------------------------- -->
      <div class="wrap-input1 validate-input">
        <textarea class="input1" name="description" placeholder="Description" id="descript"></textarea>
        <span class="shadow-input1"></span>
        <span id="des" class="text-warning"></span>
      </div>
      <!-- ................................................................. -->


      <div class="container-contact1-form-btn">
        <button class="contact1-form-btn" type="submit" name="submitx" onclick="formx();">
          <!--  -->

          <span id="book">
            Book Now
            <i class="fa fa-long-arrow-right" aria-hidden="true"></i>
          </span>
        </button>
        <br>
      </div>
      </form>
      <div class="copy" id="footer">
          <span style="margin-left:393px;margin-bottom:1px;"> &copy; 2020 ECS. All Rights Reserved | Design by <a href="http://w3layouts.com/" target="_blank"></a> </span>
        </div>
  </div>
  <style>
   #footer {
    background-color: #fcfcfc;
    margin-left:-573px;
    width:2000px;
   }
  </style>
  <script type="text/javascript">
    function formx()
    {
   //   var descript = document.getElementById('descript').value;
   //   if (descript == "") {
    //    document.getElementById('descript').innerHTML = "** please fill the description";
     //   return false;
   //   }
   //   if (descript.length < 3) {
  //      document.getElementById('descript').innerHTML = "** invalid description";
      //  return false;
   //   }
    //  if (descript.length > 20) {
   //     document.getElementById('descript').innerHTML = "**description field exceeded the limit to 20";
   //     return false;
    //  }
   //   var exp = /^[\W]+$/;
   //   var result = exp.test(descript);
 //     if (result) {
    //    document.getElementById('descript').innerHTML = "** special character are not allowed";
   //     return false;
 //     } 
        form=document.getElementById('bookingx');
        // form.target='_blank';
        form.action='bookDb.php';
        form.submit();
        
    }
</script>

  <!--===============================================================================================-->
  <script src="book/vendor/jquery/jquery-3.2.1.min.js"></script>
  <!--===============================================================================================-->
  <script src="book/vendor/bootstrap/js/popper.js"></script>
  <script src="book/vendor/bootstrap/js/bootstrap.min.js"></script>
  <!--===============================================================================================-->
  <script src="book/vendor/select2/select2.min.js"></script>
  <!--===============================================================================================-->
  <script src="book/vendor/tilt/tilt.jquery.min.js"></script>
  <script>
    $('.js-tilt').tilt({
      scale: 1.1
    })
  </script>

  <!-- Global site tag (gtag.js) - Google Analytics -->
  <script async src="https://www.googletagmanager.com/gtag/js?id=UA-23581568-13"></script>
  <script>
    window.dataLayer = window.dataLayer || [];

    function gtag() {
      dataLayer.push(arguments);
    }
    gtag('js', new Date());

    gtag('config', 'UA-23581568-13');
  </script>

  <!--===============================================================================================-->
  <script src="book/js/main.js"></script>

  <!-- </form> -->
</body>

</html>
<script src="node_modules/jquery/dist/jquery.min.js"></script>
<script src="node_modules/popper.js/dist/umd/popper.min.js"></script>
<script src="node_modules/bootstrap/dist/js/bootstrap.min.js"></script>
<script src="node_modules/chart.js/dist/Chart.min.js"></script>
<script src="node_modules/perfect-scrollbar/dist/js/perfect-scrollbar.jquery.min.js"></script>
<script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyB5NXz9eVnyJOA81wimI8WYE08kW_JMe8g&callback=initMap" async defer></script>
<script src="js/off-canvas.js"></script>
<script src="js/hoverable-collapse.js"></script>
<script src="js/misc.js"></script>
<script src="js/chart.js"></script>
<script src="js/maps.js"></script>