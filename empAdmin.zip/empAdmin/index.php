<?php session_start();
//echo $_SESSION['empId'];
$conn = mysqli_connect('localhost', 'root', '', 'ExpressCourier');
if ($_SESSION['empId'] == "") {
  echo "<script>alert('You must login first')</script>";
  header("Location: http://localhost/ExpressCourier/login/loginIndex.php");
}




?>
<!-- Will be used to take empId and Username(<= from db) -->


<!DOCTYPE html>
<html lang="en">

<head>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <title>Employee Admin</title>
  <link rel="stylesheet" href="node_modules/font-awesome/css/font-awesome.min.css" />
  <link rel="stylesheet" href="node_modules/perfect-scrollbar/dist/css/perfect-scrollbar.min.css" />
  <link rel="stylesheet" href="node_modules/flag-icon-css/css/flag-icon.min.css" />
  <link rel="stylesheet" href="css/style.css" />
  <link rel="shortcut icon" href="images/favicon.png" />
  <link href='https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css'>
  <!--<script src='https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js'></script>-->
  <link href='https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css'>
  <script src='https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js'></script>
  <style>
    #progress {
      width: 600px;
      height: 175px;
    }

    #content {
      margin-bottom: auto;
      height: auto;
    }

    p.track {
      margin: 5px;
      padding: 5px;
    }

    #sidebar {
      height: 1110px;
    }



    .card {
      z-index: 0;
      background-color: #ECEFF1;
      padding-bottom: 5px;
      margin-top: 6px;
      margin-bottom: 6px;
      border-radius: 6px
    }

    .top {
      padding-top: 40px;
      padding-left: 13% !important;
      padding-right: 13% !important;
    }

    

    .icon {
      width: 23px;
      height: 23px;
      margin-left: 3px
    }

    .icon-content {
      padding-bottom: 3px;
      height: 2px;
    }

    @media screen and (max-width: 552px) {
      .icon-content {
        width: 3%
      }
    }

    #email {
      padding-bottom: 2px;
    }

    #order1 {
      height: 378px;
    }

    #order2 {
      height: 378px;
      width: 495px;
    }

    #last {
      padding-bottom: 13px;

    }
    #profilePicTop{
      width:42px;
      padding-top:0px;
      padding-bottom:0px;
      padding-left:8px;
      position:absolute;
      left: 170px;
       top: 130px;

    }
    #welcomeDiv{
      display:none;
      height:110px;
      width:210px;
      padding-top:15px;
      padding-left:8px;
     background-color: lightblue;
     position:absolute;
      left: 20px;
       top: 140px;
       margin-left:-14px;
       margin-top:67px;

    }
    #uploadProfile{
      height:12px;
      width:60px;
      padding-top:0px;
      padding-left:2px;
      padding-right:2px;
      padding-bottom:0px;
      position:absolute;
      bottom:2px;
      left: 140px;

    }
    #nav {
      margin-top:88px;
    }
  </style>
</head>

<body>
  <div class=" container-scroller">
    <!-- partial:partials/_navbar.html -->
    <nav class="navbar navbar-default col-lg-12 col-12 p-0 fixed-top d-flex flex-row">
      <div class="bg-white text-center navbar-brand-wrapper">
        <a class="navbar-brand brand-logo" href="index.php"><img src="images/timthumb.png" width="65" height="65" /></a>
        <a class="navbar-brand brand-logo-mini" href="index.php"><img src="images/logo_star_mini.jpg"></a>
      </div>
      <div class="navbar-menu-wrapper d-flex align-items-center">
        <button class="navbar-toggler navbar-toggler d-none d-lg-block navbar-dark align-self-center mr-3" type="button" data-toggle="minimize">
          <span class="navbar-toggler-icon"></span>
        </button>
        <!-- <form class="form-inline mt-2 mt-md-0 d-none d-lg-block">
          <input class="form-control mr-sm-2 search" type="text" placeholder="Search">
        </form> -->
        <ul class="navbar-nav ml-lg-auto d-flex align-items-center flex-row">
          <li class="nav-item">
     
          <!-- ------------------------For profile pic edit button ------------------------------------->
          <div id="welcomeDiv"  style="" class="answer_list" >
            <form action="index.php" method="post" enctype="multipart/form-data">
                <span class="menu-title text-info bg-dark" style="">upload profile pic here</span>
                <input type="file" name="upload-file" value="" required>
                  <input id="uploadProfile" type="submit" name="submit" value="Upload" class="btn btn-primary" style="margin-top:52px;" >
                  <span id="pic"></span>
                  </form>
                </div>

                <script>
                  var show = false;
                function showDiv() {
                   document.getElementById('welcomeDiv').style.display = "block";
                  }
                function hideDiv(){
                  document.getElementById('welcomeDiv').style.display = "none";
                }
                function controlDisplay()
                {
                  if(show == true)
                  {
                     hideDiv();
                     
                  }
                  else
                  {
                     showDiv();
                  }
                  show=!show;
                  console.log(show);
                }
                function upload() {
                  
             if(uploadfile.value == '')
            { 
              var uploadfile = document.getElementById('uploadProfile').value;
               document.getElementById('pic').innerHTML ="** Please upload the picture";
                return false;
            }
                }
                </script>
                <?php
                              if (isset($_POST['submit'])){
                                $filename = $_FILES["upload-file"]['name'];
                                $folder = 'images/'.$filename;
                                $tempfilename = $_FILES["upload-file"]['tmp_name'];
                                move_uploaded_file($tempfilename,$folder);
                                // echo "<img src='$folder' height='100' widht='100'/>";
                                $conn = mysqli_connect('localhost','root','','expresscourier');
                                $empId= $_SESSION['empId'];
                                $query="UPDATE employeeregistration SET empProfile='$folder' WHERE empId= '$empId'";
                                mysqli_query($conn,$query);
                                $_POST['submit']="";
                                }
                ?>
          
           <!-- ------------------------------------------------ -->

            <a class="nav-link profile-pic" href="#"><img class="rounded-circle" src="<?php 
            //for profile pic . On the top.
            $empId= $_SESSION['empId'];
            $profilePic = "";
            $conn = mysqli_connect("localhost",'root','','expresscourier');
            $query = "SELECT empProfile FROM employeeRegistration where empId='$empId'" ;
            $result = mysqli_query($conn,$query);
            while($row=mysqli_fetch_array($result)){
              $profilePic = $row['empProfile']; 
            }
            $_SESSION['$profilePic']=$profilePic;
            echo $profilePic;
            
            ?>" alt=""></a>
  



          </li>
          <li class="nav-item">
            <a class="nav-link" href="signout.php"><i class="fa fa-sign-out"></i></a>
          </li>
        </ul>
        <button class="navbar-toggler navbar-dark navbar-toggler-right d-lg-none align-self-center" type="button" data-toggle="offcanvas">
          <span class="navbar-toggler-icon"></span>

        </button>
      </div>
    </nav>

    <!-- partial -->
    <div class="container-fluid">
      <div class="row row-offcanvas row-offcanvas-right">
        <!-- partial:partials/_sidebar.html -->
        <nav class="bg-white sidebar sidebar-offcanvas" id="sidebar">
          <div class="user-info">
                        <img src="<?php 
                        //for profile pic On side bar.
                        $empId= $_SESSION['empId'];
                        $profilePic = "";
                        $conn = mysqli_connect("localhost",'root','','expresscourier');
                        $query = "SELECT empProfile FROM employeeRegistration where empId='$empId'" ;
                        $result = mysqli_query($conn,$query);
                        while($row=mysqli_fetch_array($result)){
                          $profilePic = $row['empProfile']; 
                        }
                        echo $profilePic;
                        ?>" alt="" width="90" height="90">
            <input class = "btn btn-success" type="button" value="<?php echo "EmpId: ".$empId; ?>">
            <!-- -----------------------------Edit button----------------------------------- -->
            <div class="text-center">  
            <button id ="profilePicTop" type="button" class="btn btn-primary" onclick="controlDisplay()"  >Edit</button>
             </div>
             <!-- -----------------------------Edit button----------------------------------- -->
            <p class="name"></p>
            <p class="designation"></p>
            <span class="online"></span>
         
           
          </div>
          <ul class="nav" id="nav">
            <li class="nav-item active">
              <a class="nav-link" href="index.php">
                <img src="images/icons/1.png" alt="">
                <span class="menu-title">Dashboard</span>
              </a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="book1.php">
                <img src="images/icons/005-forms.png" alt="">
                <span class="menu-title">Booking</span>
              </a>
            </li>
            
            <!--<li class="nav-item">
              <a class="nav-link" href="contact.html">
                <img src="images/icons/5.png" alt="">
                <span class="menu-title">Contact Us</span>
              </a>
            </li>-->
            
          </ul>
        </nav>

        <!-- partial -->
        <div class="content-wrapper" id="content">
          <h3 class="page-heading mb-4"></h3>
          <div class="row">
            <div class="col-md-6 mb-5">
              <div class="card" id="order1">
                <div class="card-body">
                  <h5 class="card-title">Orders</h5>
                  <div class="row">
                    <div class="col-9">
                      <div class="mb-4">
                      <p class="card-text text-muted mb-2">Pending parcels</p>
                        <div class="progress progress-slim">
                          <div class="progress-bar bg-warning" role="progressbar" style="width: 
                          <?php 
                          $empId = $_SESSION['empId'];
                          $query = "select status from booking where status = 0 and empId='$empId'"; //checking booking table for deliver parcles.2 is for delivery.
                          $status0 = array();
                          $result = mysqli_query($conn,$query);
                          while($row = mysqli_fetch_array($result)){
                              array_push($status0,$row['status']);
                            }
                            echo count($status0)."%";   
                          ?>"aria-valuenow="25" aria-valuemin="0" aria-valuemax="100"></div>
                        </div>
                        </div>

                        <div class="mb-4">
                        <p class="card-text text-muted mb-2">Approved and with Delivery Boy</p>
                        <div class="progress progress-slim">
                          <div class="progress-bar bg-dark" role="progressbar" style="width: 
                          
                          <?php 
                          $empId = $_SESSION['empId'];
                          $query = "select status from booking where status = 2 and empId='$empId'"; //checking booking table for deliver parcles.2 is for delivery.
                          $status0 = array();
                          $result = mysqli_query($conn,$query);
                          while($row = mysqli_fetch_array($result)){
                              array_push($status0,$row['status']);
                            }
                            echo count($status0)."%"; ?>
                            " aria-valuenow="55" aria-valuemin="0" aria-valuemax="100"></div>
                        </div>
                      </div>


                      
                      <div class="mb-4">
                        <p class="card-text text-muted mb-2">Shipped parcels</p>
                        <div class="progress progress-slim">
                          <div class="progress-bar bg-success" role="progressbar" style="width: 

                    <?php 
                          $empId = $_SESSION['empId'];
                          $query = "select status from booking where status = 4 and empId='$empId'"; //checking booking table for deliver parcles.2 is for delivery.
                          $status0 = array();
                          $result = mysqli_query($conn,$query);
                          while($row = mysqli_fetch_array($result)){
                              array_push($status0,$row['status']);
                            }
                            echo count($status0)."%"; ?>
                          
                          
                          
                          
                          " aria-valuenow="25" aria-valuemin="0" aria-valuemax="100"></div>
                        </div>
                      </div>

                      <div class="mb-4">
                        <p class="card-text text-muted mb-2">Undelivered parcels</p>
                        <div class="progress progress-slim">
                          <div class="progress-bar bg-danger" role="progressbar" style="width: 

                    <?php 
                          $empId = $_SESSION['empId'];
                          $query = "select status from booking where status = 3 and empId='$empId'"; //checking booking table for deliver parcles.2 is for delivery.
                          $status0 = array();
                          $result = mysqli_query($conn,$query);
                          while($row = mysqli_fetch_array($result)){
                              array_push($status0,$row['status']);
                            }
                            echo count($status0)."%"; ?>
                          
                          
                          
                          
                          
                          
                          
                          " aria-valuenow="55" aria-valuemin="0" aria-valuemax="100"></div>
                        </div>
                      </div>

                      
                     
                    </div>
                    <div class="col-12">
                      <p class="text-muted mb-0">
                        Note: Order details get updated every 10 minutes
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div class="col-md-6 mb-4">
              <div class="card" id="order2">
                <div class="card-body">
                  <h5 class="card-title" style="margin-left:114px;">Feedback Form</h5>
                  <div class="d-flex flex-wrap justify-content-between justify-content-md-center justify-content-xl-between align-items-center">

                    <form action="feedback.php" method="POST"  name="myform" >
                      <!-- created form to take feed back from employee (feedback.php) -->
                      <p style="font-size:15px;margin-left:110px;margin-right:33px;">Please provide feedback below :

                        <br>
                        <label class="radio-inline">
                          <input type="radio" name="experience" id="radio_experience" value="Bad" style="vertical-align:middle;" required>
                          Bad
                          <input type="radio" name="experience" id="radio_experience" value="Average" style="vertical-align:middle;" required>
                          Average
                          <input type="radio" name="experience" id="radio_experience" value="Good" style="vertical-align:middle;" required>
                          Good
                        </label><br>
                        <span id="radio1" class="text-danger"></span>
                        <label for="comments">Comments:</label>
                        <textarea class="form-control" type="textarea" name="comments" id="comments" placeholder="Your Comments" maxlength="600" rows="3" required></textarea>
                        <span id="SpanComments" class="text-info"></span>
                        <br>
                        <label for="name">Email-id:</label>
                        <input type="email" class="form-control" name="emailid" id = "email" placeholder="Your Email" required>
                        <span id="emailid" class="text-info"></span>
                        <br>
                        <button type="submit" name="submit" onclick="return validate()">Post </button>
                      </p>
                    </form>
                     </diV>
                </div>
              </div>
            </div>
          </div>
          <div class="card-deck">
            <div class="card col-lg-12 px--0 mb-4">
              <div class="card-body" id="last">
                <h5 class="card-title" style="text-align:center;">Last Orders :</h5>
                <div class="table-responsive">
                  <?php
                  $conn = mysqli_connect('localhost', 'root', '', 'ExpressCourier');
                  $order = array();
                  $toname = array();
                  $empId = array();
                  $oredrOn = array();
                  $contact = array();
                  $desc = array();
                  $staus = array();

                  //echo "Connected  \n";
                  $employeeId = $_SESSION['empId'];

                   //$query = "select * from booking";
                   $query = "select * from booking where empId='$employeeId'";
                  

                  $result = mysqli_query($conn, $query);
                  while ($row = mysqli_fetch_array($result)) {
                    array_push($order, $row['orderId']);
                    array_push($toname, $row['toname']);
                    array_push($empId, $row['sendTo']);
                    array_push($oredrOn, $row['date']);
                    array_push($contact, $row['contact']);
                    array_push($desc, $row['description']);
                    array_push($staus, $row['status']);
                  }



                  ?>

                  <table class="table center-aligned-table">
                    <thead>
                      <tr class="text-primary">
                        <th>Order Id</th>
                        <th>To </th> <!-- to employee  -->
                        <th> His. Id.</th>
                        <th>Ordered On</th> <!-- Date  -->
                        <th>Contact</th>
                        <th>Description</th>
                        <th>Status</th>
                        <!-- <th>Change </th> -->
                      </tr>
                    </thead>
                    <tbody>
                      <?php
                      $size = count($order);
                      for ($i = 0; $i < $size; $i++) {
                        echo "<tr class=''>";
                        echo "<td>$order[$i]</td>";
                        echo "<td>$toname[$i]</td>";
                        echo "<td>$empId[$i]</td>";
                        echo "<td>$oredrOn[$i]</td>";
                        echo "<td>$contact[$i]</td>";
                        echo "<td>$desc[$i]</td>";


                        if ($staus[$i] == '0') {
                          echo "<td><span class='btn btn-warning'>Pending</span></td>";
                        } elseif ($staus[$i] == '1') {
                          echo "<td><span class='btn btn-info'>Approved</span></td>";
                        } elseif ($staus[$i] == '2') {
                          echo "<td><span class='btn btn-dark'>With Delivery Boy</span></td>";
                        }
                         elseif ($staus[$i] == '4') {
                          echo "<td><span class='btn btn-success'>Delivered</span></td>";
                        } elseif ($staus[$i] == '3' ) {

                          $query_remark = "SELECT * from remark where orderId='$order[$i]'";
                          $remark_run = mysqli_query($conn, $query_remark);


                          while ($row1 = mysqli_fetch_array($remark_run)) {
                            if ($row1['r_region'] == '1') {
                              $xx = 'Unavailable';
                            } elseif ($row1['r_region'] == '2') {
                              $xx = 'Return';
                            } elseif ($row1['r_region'] == '3') {
                              $xx = 'Other';
                            }



                            echo  "<td><button type='button' class='btn btn-danger' data-toggle='tooltip' data-placement='top' title='$xx'>
											Reason for Undelivered
										</button></td>";
                          }
                        }
                        #echo "<td> <button>Cancel</button></td>";
                        echo "</tr>";
                      }
                      ?>
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          </div>
        </div>
        <!-- partial:partials/_footer.html -->
        <!-- partial -->
      </div>
    </div>
    <div class="copy" id="footer">
          <p style="margin-left:23px;"> &copy; 2020 ECS. All Rights Reserved | Design by <a href="http://w3layouts.com/" target="_blank"></a> </p>
        </div>
  </div>
  <style>
    #footer {
      margin-left:570px;
      background-color: #fcfcfc;
      width: 2000px;
    }
  </style>
  <script src="node_modules/jquery/dist/jquery.min.js"></script>
  <script src="node_modules/popper.js/dist/umd/popper.min.js"></script>
  <script src="node_modules/bootstrap/dist/js/bootstrap.min.js"></script>
  <script src="node_modules/chart.js/dist/Chart.min.js"></script>
  <script src="node_modules/perfect-scrollbar/dist/js/perfect-scrollbar.jquery.min.js"></script>
  <!-- <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyB5NXz9eVnyJOA81wimI8WYE08kW_JMe8g&callback=initMap" async defer></script>-->
  <script src="js/off-canvas.js"></script>
  <script src="js/hoverable-collapse.js"></script>
  <script src="js/misc.js"></script>
  <script src="js/chart.js"></script>
  <script src="js/maps.js"></script>
  <script>
    function validate() {
        // alert("clicked")
        // console.log("I am working")
          let email = document.querySelector('#email')
          let comment = document.querySelector('#comments')
          //for comment
          if (comment.value.length <= 5) {
            document.querySelector('#SpanComments').innerHTML = "Please provide some more details"
            timeOut('SpanComments',comment)
            return false

          }
          //for email
          const re = /^[a-zA-Z][a-zA-Z0-9-_\.]+@([a-zA-Z]|[a-zA-Z0-9]?[a-zA-Z0-9-]+[a-zA-Z0-9])\.[a-zA-Z0-9]{2,10}(?:\.[a-zA-Z]{2,10})?$/;
          if (!re.test(String(email.value).toLowerCase())){
            document.querySelector('#emailid').innerHTML = "Please Provide Valid Email."
            timeOut('emailid',email);
            return false
          }
          function timeOut(id,elemBorder){
            setTimeout(() => {
              document.querySelector(`#${id}`).innerHTML  = ""
              
            }, 2500);
            elemBorder.style.borderColor = 'skyblue'
          }
      }
    
        
      
    
    
  
  
  </script>

  <script>
    $(function() {
      $('[data-toggle="tooltip"]').tooltip()
    })
  </script>

</body>
<script> console.log("1")</script>
</html>