
<html>

<body>
<div class="wrap-input1 validate-input" style="border-radius:20px;width:390px;color:gray;height:50px;" >
        <!--<input class="input1" type="" name="email" placeholder="Email">-->
        <select name="parcel_type" id="input"class ="input1"style="border-radius:20px;width:390px;color:gray;height:50px;"  oninput="myFunction()">
         <option value="Choose Parcel type" hidden>Choose Parcel Type</option>
          <option value="documents" >documents</option>
          <option value="parcel">parcel</option>
          <option value="computer parts">computer parts</option>
        </select>
        <!--<span class="shadow-input1"></span>-->
      </div>
    <script>
    function myFunction(){
        var res= document.getElementById('input').value;
    }
    var res= document.getElementById('input').value;
  
  

    </script>

<?php
   echo "<script>document.writeln(res);</script>";
?>




</body>
</html>