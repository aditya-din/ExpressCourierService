<?php
session_start();
$_SESSION['empId']="";
?>

<!DOCTYPE html>
<html lang="en">

<head>

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">
  <style>
  .logo-image{
    width: 81px;
    height: 31px;
    border-radius: 70%;
    overflow: hidden;
    margin-top: -4px;
}

  </style>

  <title>Home</title>

  <!-- Bootstrap core CSS -->
  <link href="css/bootstrap.min.css" rel="stylesheet">

  <!-- Custom styles for this template -->
  <link href="css/scrolling-nav.css" rel="stylesheet">

</head>

<body id="page-top">

  <!-- Navigation -->
  <nav class="navbar navbar-expand-lg navbar-gray bg-dark fixed-top" id="mainNav">
    <div class="container">
      <a class="navbar-brand js-scroll-trigger" href="#page-top"><div class="logo-image"><img src="timthumb.png" class="img-fluid"></div></a>
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation" >
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarResponsive">
        <ul class="navbar-nav ml-auto">
		<li class="nav-item">
            <a class="nav-link js-scroll-trigger" href="#">Home</a>
          </li>
		  <li class="nav-item">
            <a class="nav-link js-scroll-trigger" href="login/loginIndex.php">Login</a>
          </li>
          <li class="nav-item">
            <a class="nav-link js-scroll-trigger" href="#about">About</a>
          </li>
          <li class="nav-item">
            <a class="nav-link js-scroll-trigger" href="#services">Services</a>
          </li>
          <li class="nav-item">
            <a class="nav-link js-scroll-trigger" href="#contact">Contact</a>
          </li>
        </ul>
      </div>
    </div>
  </nav>

  <header class="bg-primary text-white" id="header">
    <div class="container text-center" >
      <h1 style="color:black";>Express Courier Service (ECS)</h1>
    </div>
  </header>

  <section id="about">
    <div class="container">
      <div class="row">
        <div class="col-lg-8 mx-auto">
          <h2>About Us</h2>
          <p class="lead"><strong>This application is used for transfer parcels and documents related to the company to different branches of the company in one day within the city.</strong></p>
          <ul>
            <li>Fast delivery of parcel within a day</li>
            <li>The purpose of this application is the hassle-free delivery of a product of the company. </li>
            <li>The feature of this application is to satisfy the customer requirement such as tracking, searching, internal support and invoice generate for booked product</li>
          </ul>
        </div>
      </div>
    </div>
  </section>

  <section id="services" class="bg-light">
    <div class="container">
      <div class="row">
        <div class="col-lg-8 mx-auto">
          <h2>Services we offer</h2>
          <ul>
      <li><a href="">Booking</a></li>
		  <li><a href="">Status info</a></li>
		  <li><a href="index1.html">Taking Feedback</a></li>
		  </ul>
        </div>
      </div>
    </div>
  </section>

  <section id="contact">
    <div class="container">
      <div class="row">
        <div class="col-lg-8 mx-auto">
          <h2>Contact us</h2>
          <p class="lead">Email Id : expresscourier@gmail.com</p>
		   <p class="lead">Chat: <a href="
		   ">Message</a></p>
        </div>
      </div>
    </div>
  </section>

  <!-- Footer -->
  <footer class="py-5 bg-dark">
    <div class="container">
      <p class="m-0 text-center text-white">2020 @ Copyright Online Express Courier Service. All Rights Reserved.</p>
    </div>
    <!-- /.container -->
  </footer>

  <!-- Bootstrap core JavaScript -->
  <script src="vendor/jquery/jquery.min.js"></script>
  <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

  <!-- Plugin JavaScript -->
  <script src="vendor/jquery-easing/jquery.easing.min.js"></script>

  <!-- Custom JavaScript for this theme -->
  <script src="js/scrolling-nav.js"></script>

</body>

</html>
