-- phpMyAdmin SQL Dump
-- version 4.9.2
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Apr 24, 2020 at 08:15 PM
-- Server version: 10.4.11-MariaDB
-- PHP Version: 7.2.26

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `expresscourier`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `adminId` varchar(255) NOT NULL,
  `adminName` varchar(255) NOT NULL,
  `pass` varchar(255) NOT NULL,
  `date` date NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`adminId`, `adminName`, `pass`, `date`) VALUES
('aditya123', 'Aditya', 'aditya123', '2020-04-04'),
('psk', 'psk', 'psk', '2020-04-02');

-- --------------------------------------------------------

--
-- Table structure for table `booking`
--

CREATE TABLE `booking` (
  `sendTo` varchar(255) NOT NULL,
  `empId` varchar(255) NOT NULL,
  `address` varchar(255) NOT NULL,
  `description` varchar(500) NOT NULL,
  `type` varchar(100) NOT NULL,
  `orderId` varchar(255) NOT NULL,
  `contact` varchar(20) NOT NULL,
  `toname` varchar(255) NOT NULL,
  `date` date NOT NULL DEFAULT current_timestamp(),
  `status` varchar(255) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `booking`
--

INSERT INTO `booking` (`sendTo`, `empId`, `address`, `description`, `type`, `orderId`, `contact`, `toname`, `date`, `status`) VALUES
('Mahi122', 'LG121', 'near mahindra showroom bangalore', '1st booking', 'documents', 'ORD5ea1df1ae1b9b', '8147087117', 'Aditya', '2020-04-24', '3'),
('Mahi122', 'LG121', 'banashankari', '2nd parcel', 'documents', 'ORD5ea1ecaab92a6', '9708233300', 'Rajeev', '2020-04-24', '3'),
('Mahi122', 'LG121', 'koromangala', 'For pending', 'documents', 'ORD5ea1f1de6bfec', '9191871927', 'Sudheer', '2020-04-24', '4'),
('Mahi122', 'LG121', 'MG Road', 'Testing on 24th april', 'computer parts', 'ORD5ea3065f5897f', '8127087117', 'Alok', '2020-04-24', '0'),
('Mahi122', 'LG121', 'Kumarswamy layout', 'Another testng', 'documents', 'ORD5ea314e321954', '8127087117', 'Shivam', '2020-04-24', '1');

-- --------------------------------------------------------

--
-- Table structure for table `contact`
--

CREATE TABLE `contact` (
  `slno` int(255) NOT NULL,
  `fname` varchar(255) NOT NULL,
  `lname` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `msg` varchar(255) NOT NULL,
  `date` date NOT NULL DEFAULT current_timestamp(),
  `contact` varchar(255) NOT NULL,
  `empId` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `employeeregistration`
--

CREATE TABLE `employeeregistration` (
  `empId` varchar(255) NOT NULL,
  `empName` varchar(255) NOT NULL,
  `deptName` varchar(255) NOT NULL,
  `pass` varchar(255) NOT NULL,
  `office` varchar(255) NOT NULL,
  `contact` varchar(20) NOT NULL,
  `date` date NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `employeeregistration`
--

INSERT INTO `employeeregistration` (`empId`, `empName`, `deptName`, `pass`, `office`, `contact`, `date`) VALUES
('LG121', 'Anurag', 'management', 'LGPASS', 'office1', '8147087119', '2020-04-23'),
('Mahi122', 'Aditya', 'sales', 'LGPASS', 'office3', '8147087117', '2020-04-24');

-- --------------------------------------------------------

--
-- Table structure for table `feedback`
--

CREATE TABLE `feedback` (
  `empId` varchar(255) NOT NULL,
  `BAG` varchar(100) NOT NULL,
  `comment` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `date` date NOT NULL DEFAULT current_timestamp(),
  `slno` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `remark`
--

CREATE TABLE `remark` (
  `r_id` int(11) NOT NULL,
  `r_vendor_id` varchar(100) NOT NULL,
  `r_region` varchar(100) NOT NULL,
  `r_date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `r_order_id` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `remark`
--

INSERT INTO `remark` (`r_id`, `r_vendor_id`, `r_region`, `r_date`, `r_order_id`) VALUES
(28, 'psk', '2', '2020-04-15 15:42:05', 'ORD5e85e72fade99'),
(29, 'psk', '3', '2020-04-16 12:32:03', 'ORD5e96e07f1737e'),
(30, 'psk', '3', '2020-04-16 12:32:10', 'ORD5e96df3de038f'),
(31, 'aditya123', '2', '2020-04-23 18:38:05', 'ORD5ea1df1ae1b9b'),
(32, 'aditya123', '3', '2020-04-23 19:31:50', 'ORD5ea1ecaab92a6'),
(33, 'aditya123', '0', '2020-04-24 15:12:34', 'ORD5ea1f1de6bfec'),
(34, 'aditya123', '0', '2020-04-24 16:31:38', 'ORD5ea1f1de6bfec');

-- --------------------------------------------------------

--
-- Table structure for table `status`
--

CREATE TABLE `status` (
  `statusId` int(255) NOT NULL,
  `empId` varchar(255) NOT NULL,
  `orderId` varchar(255) NOT NULL,
  `status` varchar(200) NOT NULL,
  `description` varchar(255) NOT NULL,
  `type` varchar(255) NOT NULL,
  `date` date NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `status`
--

INSERT INTO `status` (`statusId`, `empId`, `orderId`, `status`, `description`, `type`, `date`) VALUES
(22, 'LG121', 'ORD5ea1df1ae1b9b', '0', '1st booking', 'documents', '2020-04-24'),
(23, 'LG121', 'ORD5ea3065f5897f', '0', 'Testing on 24th april', 'computer parts', '2020-04-24'),
(24, 'LG121', 'ORD5ea314e321954', '0', 'Another testng', 'documents', '2020-04-24');

-- --------------------------------------------------------

--
-- Table structure for table `vContact`
--

CREATE TABLE `vContact` (
  `fname` varchar(255) NOT NULL,
  `lname` varchar(255) NOT NULL,
  `phone` varchar(20) NOT NULL,
  `msg` varchar(255) NOT NULL,
  `date` date NOT NULL DEFAULT current_timestamp(),
  `v_name` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `vContact`
--

INSERT INTO `vContact` (`fname`, `lname`, `phone`, `msg`, `date`, `v_name`) VALUES
('Aditya', 'Anand', '8147087117', 'Some thing related to #', '2020-04-24', 'aditya123');

-- --------------------------------------------------------

--
-- Table structure for table `vendor`
--

CREATE TABLE `vendor` (
  `v_name` varchar(100) NOT NULL,
  `v_pass` varchar(100) NOT NULL,
  `number` varchar(20) NOT NULL,
  `date` date NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `vendor`
--

INSERT INTO `vendor` (`v_name`, `v_pass`, `number`, `date`) VALUES
('aditya123', 'aditya123', '', '2020-04-22');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`adminId`);

--
-- Indexes for table `booking`
--
ALTER TABLE `booking`
  ADD PRIMARY KEY (`orderId`),
  ADD KEY `booking_ibfk_1` (`empId`);

--
-- Indexes for table `contact`
--
ALTER TABLE `contact`
  ADD PRIMARY KEY (`slno`),
  ADD KEY `contact_ibfk_1` (`empId`);

--
-- Indexes for table `employeeregistration`
--
ALTER TABLE `employeeregistration`
  ADD PRIMARY KEY (`empId`);

--
-- Indexes for table `feedback`
--
ALTER TABLE `feedback`
  ADD PRIMARY KEY (`slno`),
  ADD KEY `feedback_ibfk_1` (`empId`);

--
-- Indexes for table `remark`
--
ALTER TABLE `remark`
  ADD PRIMARY KEY (`r_id`);

--
-- Indexes for table `status`
--
ALTER TABLE `status`
  ADD PRIMARY KEY (`statusId`),
  ADD KEY `empId` (`empId`),
  ADD KEY `status_ibfk_2` (`orderId`);

--
-- Indexes for table `vendor`
--
ALTER TABLE `vendor`
  ADD UNIQUE KEY `v_name` (`v_name`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `contact`
--
ALTER TABLE `contact`
  MODIFY `slno` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `feedback`
--
ALTER TABLE `feedback`
  MODIFY `slno` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `remark`
--
ALTER TABLE `remark`
  MODIFY `r_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=35;

--
-- AUTO_INCREMENT for table `status`
--
ALTER TABLE `status`
  MODIFY `statusId` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `booking`
--
ALTER TABLE `booking`
  ADD CONSTRAINT `booking_ibfk_1` FOREIGN KEY (`empId`) REFERENCES `employeeregistration` (`empId`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `contact`
--
ALTER TABLE `contact`
  ADD CONSTRAINT `contact_ibfk_1` FOREIGN KEY (`empId`) REFERENCES `employeeregistration` (`empId`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `feedback`
--
ALTER TABLE `feedback`
  ADD CONSTRAINT `feedback_ibfk_1` FOREIGN KEY (`empId`) REFERENCES `employeeregistration` (`empId`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `status`
--
ALTER TABLE `status`
  ADD CONSTRAINT `status_ibfk_1` FOREIGN KEY (`empId`) REFERENCES `employeeregistration` (`empId`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `status_ibfk_2` FOREIGN KEY (`orderId`) REFERENCES `booking` (`orderId`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
