    <?php
      // connect to mongodb
      $m = new MongoDB\Driver\Manager("mongodb://alex:mypassword@10.111.0.2:27017/");
      echo "Connection to database successfully";
      // select a database

$m = new MongoDB\Driver\Manager("mongodb://alex:mypassword@10.111.0.2:27017/");
      echo "Database examplesdb selected";
    ?>