<?php
// code for login of employee.
session_start();
$conn = mysqli_connect("localhost","root","","expressCourier");
if(!$conn)
{
    echo "Some problem in connecting DB";
}
else
{
    if(isset($_POST['empId'])){
    
            $empId = $_POST['empId'];
            $pass = $_POST['pass'];
            $query = "select * from employeeRegistration where empId = '$empId' and pass = '$pass'"; 
            $result= mysqli_query($conn,$query);
            $num = mysqli_num_rows($result);
            if($num == 1)
            {
                $_SESSION['empId'] = $empId; //taking employee id from here into session variable
                header ("Location: http://localhost/ExpressCourier/empAdmin/index.php");
            }
            else{
                echo "<script type='text/javascript'>alert('check email or password or Try signup');</script>"; 
            }
        }
}