<?php
session_start();
$conn = mysqli_connect("localhost","root","","expresscourier");
if(!$conn)
{
	echo "Some problem in connection to (vendor table)";
}
else{
    //echo "connection to courier database is successful";
    

    $id = rand(100,1000);
    $uname = $_POST['uname'];
    $loginId = $uname.$id; //unique login Id for every deilivry boy.
    $pass = $_POST['pass'];
    $contact = $_POST['contact'];
    $checking = "select * from vdeliveryboy where v_id = '$loginId'";
    $result = mysqli_query($conn,$checking);
    $num = mysqli_num_rows($result);
    if($num>=1)
    {
        
        echo "<script>alert('Name already exist');</script>";
        header ("Location: http://localhost/ExpressCourier/delivery/examples/Registration/registration1.html");
        

    }
   else{
        $register = "INSERT INTO vdeliveryboy(v_id,v_name,v_pass,number) VALUES ('$loginId','$uname','$pass','$contact')";
        mysqli_query($conn,$register);
        echo "<br>";
        echo "<br>";
        echo "<script>alert('Successful. Now you can do login with same name and pass.')</script>";
        header ("Location: http://localhost/ExpressCourier/delivery/examples/login.php");
      
    }
    

    
}






?>



