<?php

$conn = mysqli_connect("localhost","root","","expressCourier");


    if(isset($_POST['v_submit']))
    {
            session_start();
            $user = $_POST['v_id'];
            $pass = $_POST['v_pass'];
            $query = "select * from vdeliveryboy where v_id='$user' and v_pass='$pass'";
            $result= mysqli_query($conn,$query);
            $num = mysqli_num_rows($result);
            if($num == 1)
            {
                $_SESSION['v_id']=$user;
                echo "successful login as a vdeliveryboy";
                header ("location: http://localhost/ExpressCourier/delivery/examples/dashboard.php");
                
            }
            
        else{
            echo "Username and Password is incorrect";
            header ("location: http://localhost/ExpressCourier/delivery/examples/login.php");
          }
}

?>
 