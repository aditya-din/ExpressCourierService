<?php
session_start();
$conn = mysqli_connect("localhost", "root", "", "expressCourier");
  if ($_SESSION['v_id']==""){
    header("Location: http://localhost/ExpressCourier/delivery/examples/login.php");
  }
?>
<?php
$conn = mysqli_connect("localhost", "root", "", "ExpressCourier");
if (isset($_POST['route'])) {
  $from = 'Banglore';
  $to = $_POST['to'];



  header("Location:https://www.google.com/maps/dir/" . $from . "/" . $to . " ");
  #header("Location:track.php");

}

?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8" />
  <link rel="apple-touch-icon" sizes="76x76" href="../assets/img/apple-icon.png">
  <link rel="icon" type="image/png" href="../assets/img/favicon.png">
  <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
  <title>
    ECS Delivery Dashboard
  </title>
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>
  <meta content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0, shrink-to-fit=no' name='viewport' />
  <!--     Fonts and icons     -->
  <link href="https://fonts.googleapis.com/css?family=Montserrat:400,700,200" rel="stylesheet" />
  <link href="https://maxcdn.bootstrapcdn.com/font-awesome/latest/css/font-awesome.min.css" rel="stylesheet">
  <!-- CSS Files -->
  <link href="../assets/css/bootstrap.min.css" rel="stylesheet" />
  <link href="../assets/css/paper-dashboard.css?v=2.0.1" rel="stylesheet" />
  <!-- CSS Just for demo purpose, don't include it in your project -->
  <link href="../assets/demo/demo.css" rel="stylesheet" />
</head>

<body class="">
  <div class="wrapper ">
    <div class="sidebar" data-color="white" data-active-color="danger">
      <div class="logo">
        <a href="" class="simple-text logo-mini">

        </a>
        <a href="https://www.creative-tim.com" class="simple-text logo-normal">
          <span style="font-size:23px;"><b>ECS</b></span> <br/>
          <span> Login Id: <?php echo $_SESSION['v_id'];?> </span>

        </a>
      </div>
      <div class="sidebar-wrapper">
        <ul class="nav">
          <li class="active ">
            <a href="./dashboard.html">
              <i class="nc-icon nc-bank"></i>
              <p>Dashboard</p>
            </a>
          </li>
          <!-- <li>
            <a href="contact.php">
              <i class="nc-icon nc-diamond"></i>
              <p>Contact us</p>
            </a>
          </li> -->

        </ul>
      </div>
    </div>
    <div class="main-panel">
      <!-- Navbar -->
      <nav class="navbar navbar-expand-lg navbar-absolute fixed-top navbar-transparent">
        <div class="container-fluid">
          <div class="navbar-wrapper">
            <div class="navbar-toggle">
              <button type="button" class="navbar-toggler">
                <span class="navbar-toggler-bar bar1"></span>
                <span class="navbar-toggler-bar bar2"></span>
                <span class="navbar-toggler-bar bar3"></span>
              </button>
            </div>
            <a class="navbar-brand" href="javascript:;">Delivery boy Dashboard</a>
          </div>
          <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navigation" aria-controls="navigation-index" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-bar navbar-kebab"></span>
            <span class="navbar-toggler-bar navbar-kebab"></span>
            <span class="navbar-toggler-bar navbar-kebab"></span>
          </button>
          <div class="collapse navbar-collapse justify-content-end" id="navigation">

            <ul class="navbar-nav">

              <li class="nav-item">
                <a class="nav-link btn-rotate" href="vlogout.php">
                  <span id="">Logout</span>

                </a>
              </li>
            </ul>
          </div>
        </div>
      </nav>
      <div class="content">
        <div class="row">
          <div class="col-lg-12 col-md-6 col-sm-6">
            <div class="card card-stats">
              <div class="card-body ">
                <div class="row">
                  <table class="table table-hover">
                    <thead>
                      <tr>
                        <th>OrderId</th>
                        <th>To</th>
                        <th>From</th>
                        <th>Address</th>
                        <th>Logistics</th>
                        <th><span class="">Action</span></th>
                       
                      </tr>
                    </thead>
                    <tbody>
                      <?php
                      $v_id = $_SESSION['v_id'];
                      $query = "select * from booking where status='2' and v_id='$v_id'";
                      $run = mysqli_query($conn, $query);
                      $count = 0;
                      while ($row = mysqli_fetch_array($run)) {
                      ?>
                        <tr>
                         <td><?= $row['orderId']; ?></td>
                          <td><?= $row['sendTo']; ?></td>
                          <td><?= $row['empId']; ?></td>
                          <td><?= $row['address']; ?></td>
                          <td><?= $row['type']; ?></td>
                          <td>
                            <div id="outer">
                              <div class="btn-in">
                                <form action="dashboard.php?orderId=<?= $row['orderId']; ?>" method="POST">
                                  <input type="text" name="to" value="<?= $row['address']; ?>" hidden>
                                  <div class="inner m-1"><input type="submit" class="btn btn-info btn-sm" value="Route" name="route"></div>
                                  
                                  <input type="text" name="delivered" value="4" hidden>
                                  <input type="submit" name="delsuccess<?= $row['orderId']; ?>" class="btn btn-success btn-sm" value="Delivered" style="margin-bottom:4px;">
                                </form>

                                <?php 
                                  if (isset($_POST['delsuccess' . $row['orderId']])) {
                                    $order_id =  $row['orderId'];
                                    $vendor =  $_SESSION['v_id']; 
                                    $item_status = '4';
                                    $reason = '0';

                                    $query4 = "UPDATE booking SET status='$item_status' WHERE orderId='$order_id'";

                                    $query5 = "INSERT INTO remark (orderId, v_id, r_region) VALUES ('$order_id','$vendor','$reason')";

                                    $run4 = mysqli_query($conn, $query4);
                                    $run5 = mysqli_query($conn, $query5);


                                    echo "<script>window.open('dashboard.php','_self')</script>";
                                  }
                                ?>

                                <!-- Button trigger modal -->
                                <button type="button" class="btn btn-primary btn-sm" data-toggle="modal" data-target="#<?= $row['orderId'] ?>">
                                  Undelivered
                                </button>
                              </div>
                              <!-- button end trigger -->

                              <!-- Modal start -->
                              <div class="modal fade" id="<?= $row['orderId'] ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                <div class="modal-dialog" role="document">
                                  <div class="modal-content">
                                    <div class="modal-header">
                                      <h5 class="modal-title" id="exampleModalLabel">Reason for Undelivered item (<?= $row['orderId'] ?>)</h5>
                                      <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                        <span aria-hidden="true">&times;</span>
                                      </button>
                                    </div>
                                    <form action="dashboard.php?orderId=<?= $row['orderId']; ?>" method="POST">
                                      <input type="text" name="orderId" value="<?= $row['orderId']; ?>" hidden>
                                      <input type="text" name="v_name" value="<?= $_SESSION['v_name']; ?>" hidden>
                                      <div class="modal-body">

                                        <div class="form-group">
                                          <input class="" type="radio" name="r_region" id="Radios1" value="1" required>
                                          <label class="" for="Radios1">Unavailable</label>

                                          <input class="" type="radio" name="r_region" id="Radios2" value="2" required>
                                          <label class="" for="Radios2">Returned</label>

                                          <input class="" type="radio" name="r_region" id="Radios3" value="3" required>
                                          <label class="" for="Radios3">Other</label>
                                        </div>

                                      </div>

                                      <div class="modal-footer">
                                        <button type="button" class="btn btn-secondary float-left" data-dismiss="modal">Close</button>
                                        <input type="submit" class="btn btn-primary" value="Submit" name="undelv<?= $row['orderId']; ?>">
                                      </div>

                                    </form>

                                    <?php
                                    if (isset($_POST['undelv' . $row['orderId']])) {
                                      $order_id = $_POST['orderId'];
                                      $region = $_POST['r_region'];
                                      $vendor = $_POST['v_name'];
                                      $item_status = '3';

                                      $query2 = "UPDATE booking SET status='$item_status' WHERE orderId='$order_id'";
                                      //$query3 = "UPDATE booking SET type='$vendor' WHERE orderId='$order_id'";

                                      $query3 = "INSERT INTO booking (orderId,v_id, r_region) VALUES ('$order_id','$vendor','$region')";
                                      //$query3 = "UPDATE booking SET v_name='$vendor',r_region='$region' WHERE orderId='$order_id'";
                                      $run2 = mysqli_query($conn, $query2);
                                      $run3 = mysqli_query($conn, $query3);

                                      echo "<script>window.open('dashboard.php','_self')</script>";
                                    }

                                    
                                    ?>

                                  </div>
                                </div>
                              </div>
                              <!-- modal end -->


                            </div>
                          </td>
                        </tr>
                      <?php } ?>

                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>



  <footer class="footer footer-black  footer-white ">
    <div class="container-fluid">
      <div class="row">
        <nav class="footer-nav">
          <ul>
            <li><a href="https://www.creative-tim.com" target="_blank">ECS</a></li>
            <li><a href="https://www.creative-tim.com/blog" target="_blank">Contact</a></li>
            <!--<li><a href="https://www.creative-tim.com/license" target="_blank">Licenses</a></li>-->
          </ul>
        </nav>
        <div class="credits ml-auto">
          <span class="copyright">
            2020 @ Copyright Online Express Courier Service. All Rights Reserved.
          </span>
        </div>
      </div>
    </div>
  </footer>
  </div>
  </div>
  <!--   Core JS Files   -->
  <script src="../assets/js/core/jquery.min.js"></script>
  <script src="../assets/js/core/popper.min.js"></script>
  <script src="../assets/js/core/bootstrap.min.js"></script>
  <script src="../assets/js/plugins/perfect-scrollbar.jquery.min.js"></script>
  <!--  Google Maps Plugin    -->
  <script src="https://maps.googleapis.com/maps/api/js?key=YOUR_KEY_HERE"></script>
  <!-- Chart JS -->
  <script src="../assets/js/plugins/chartjs.min.js"></script>
  <!--  Notifications Plugin    -->
  <script src="../assets/js/plugins/bootstrap-notify.js"></script>
  <!-- Control Center for Now Ui Dashboard: parallax effects, scripts for the example pages etc -->
  <script src="../assets/js/paper-dashboard.min.js?v=2.0.1" type="text/javascript"></script><!-- Paper Dashboard DEMO methods, don't include it in your project! -->
  <script src="../assets/demo/demo.js"></script>
  <script>
    $(document).ready(function() {
      // Javascript method's body can be found in assets/assets-for-demo/js/demo.js
      demo.initChartsPages();
    });
  </script>
  <style>
    #outer {
      width: 100%;
      text-align: center;
      float: absolute;
      margin-left: -55px;
    }

    .inner {
      display: inline-block;
    }
  </style>
</body>

</html>