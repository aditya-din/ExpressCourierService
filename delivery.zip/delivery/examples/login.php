<?php

	$conn = mysqli_connect("localhost","root","","expressCourier");
	//session_start();

?>
<!DOCTYPE html>
<html lang="en">
<head>
	<title>Login Delivery</title>
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>
  <meta content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0, shrink-to-fit=no' name='viewport' />
  <!--     Fonts and icons     -->
  <link href="https://fonts.googleapis.com/css?family=Montserrat:400,700,200" rel="stylesheet" />
  <link href="https://maxcdn.bootstrapcdn.com/font-awesome/latest/css/font-awesome.min.css" rel="stylesheet">
  <!-- CSS Files -->
  <link href="../assets/css/bootstrap.min.css" rel="stylesheet" />
  <link href="../assets/css/paper-dashboard.css?v=2.0.1" rel="stylesheet" />
  <!-- CSS Just for demo purpose, don't include it in your project -->
  <link href="../assets/demo/demo.css" rel="stylesheet" />
<!--===============================================================================================-->


</head>
<body>
	
	

				
	<div class="navbar navbar-expand-lg bg-dark mb-0 pb-0">
		<a href="#" class="navbar-brand">Delivery Boy login</a>
	</div>

	<div class="jumbotron jumbotron-fluid ">
		<div class="row">
			<div class="col-lg-4"></div>
			<div class="col-lg-4">

				<form class="login100-form validate-form" action="logincode.php" method ="post">

					<span class="login100-form-title">
						 Login
					</span>

					<div class="wrap-input100 validate-input p-3"> <!--data-validate = "Valid email is required: ex@abc.xyz" -->
						<input class="input100" type="text" name="v_id" placeholder="Your Id" required="">
						<span class="focus-input100"></span>
						<span class="symbol-input100">
							<i class="fa fa-envelope" aria-hidden="true"></i>
						</span>
					</div>

					<div class="wrap-input100 validate-input p-3" data-validate = "Password is required">
						<input class="input100" type="password" name="v_pass" placeholder="Password" required="">
						<span class="focus-input100"></span>
						<span class="symbol-input100">
							<i class="fa fa-lock" aria-hidden="true"></i>
						</span>
					</div>
					
					<div class="container-login100-form-btn p-3">
						<button class="login100-form-btn" name = "v_submit"  style="margin-right:23px;">
							Login
						<a href="Registration/Registration.html"><button class="login100-form-btn" name = "v_submit" >
							SignUp
						</a></button>
					</div>

			
					</div>
				</form>
			</div>
			<div class="col-lg-4"></div>
		</div>
	</div>		
	
	

	
<!--===============================================================================================-->	
	<script src="vendor/jquery/jquery-3.2.1.min.js"></script>
<!--===============================================================================================-->
	<script src="vendor/bootstrap/js/popper.js"></script>
	<script src="vendor/bootstrap/js/bootstrap.min.js"></script>
<!--===============================================================================================-->
	<script src="vendor/select2/select2.min.js"></script>
<!--===============================================================================================-->
	<script src="vendor/tilt/tilt.jquery.min.js"></script>
	<!--<script >
		$('.js-tilt').tilt({
			scale: 1.1
		})
	</script>-->
<!--===============================================================================================-->
	<script src="js/main.js"></script>
	

</body>
</html>